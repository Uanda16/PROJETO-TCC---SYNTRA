<?php
/**
 * SYNTRA - Envio do formulário de contato
 *
 * Usa a biblioteca "PHP Email Form" (BootstrapMade), a mesma do projeto
 * Portfolio, que fica em: vendor/php-email-form/php-email-form.php
 *
 * O formulário é enviado por AJAX pelo arquivo vendor/php-email-form/validate.js.
 * Esse script espera a resposta "OK" em caso de sucesso; qualquer outro texto
 * é exibido como mensagem de erro no formulário.
 */

// Só aceita envio pelo formulário (POST)
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    die('Método não permitido.');
}

// Configurações (e-mail de destino e SMTP) ficam em config/config.php
require __DIR__ . '/../includes/config.php';

// Biblioteca de envio
if (file_exists($php_email_form = __DIR__ . '/../vendor/php-email-form/php-email-form.php')) {
    include($php_email_form);
} else {
    die('Não foi possível carregar a biblioteca "PHP Email Form"!');
}

// Campos do formulário
$nome     = trim($_POST['name']    ?? '');
$email    = trim($_POST['email']   ?? '');
$assunto  = trim($_POST['subject'] ?? '');
$mensagem = trim($_POST['message'] ?? '');

$data_envio = date('d/m/Y');
$hora_envio = date('H:i:s');

$contact = new PHP_Email_Form;
$contact->ajax = true;

// Campo invisível anti-spam: se um robô preencher, a mensagem é descartada
$contact->honeypot = $_POST['website'] ?? '';

$contact->to         = config('email.destino_contato');
$contact->from_name  = $nome;
$contact->from_email = $email;
$contact->subject    = 'Contato pelo site SYNTRA: ' . $assunto;

// SMTP (só é usado se a senha estiver preenchida no config.php)
if (trim((string) config('email.smtp.senha', '')) !== '') {
    $contact->smtp = [
        'host'       => config('email.smtp.host'),
        'username'   => config('email.smtp.usuario'),
        'password'   => config('email.smtp.senha'),
        'port'       => config('email.smtp.porta'),
        'encryption' => config('email.smtp.encryption'),
    ];
}

$contact->add_message($nome,       'Nome', 2);
$contact->add_message($email,      'E-mail');
$contact->add_message($assunto,    'Assunto', 3);
$contact->add_message($mensagem,   'Mensagem', 10);
$contact->add_message($data_envio, 'Data de envio');
$contact->add_message($hora_envio, 'Hora do envio');

echo $contact->send();
