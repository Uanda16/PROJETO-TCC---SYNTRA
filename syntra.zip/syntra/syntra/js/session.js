/* ==========================================================
   Sessão do usuário (quem está logado)
   ========================================================== */

import { api, setCsrf } from './api.js';
import { paintAvatar, formatDate } from './ui.js';

let currentUser = null;
const listeners = new Set();

export function getUser() {
    return currentUser;
}

export function isLogged() {
    return currentUser !== null;
}

/** Avisa quando o usuário entra, sai ou atualiza o perfil. */
export function onUserChange(callback) {
    listeners.add(callback);
}

export function setUser(user) {
    const changedLogin = Boolean(user) !== Boolean(currentUser) || user?.id !== currentUser?.id;
    currentUser = user || null;
    renderHeader();
    listeners.forEach(callback => callback(currentUser, changedLogin));
}

export async function loadSession() {
    try {
        const data = await api.get('auth.php', { action: 'me' });
        setCsrf(data.csrf);
        setUser(data.user);
    } catch (error) {
        setUser(null);
        throw error;
    }
}

export async function logout() {
    const data = await api.post('auth.php?action=logout');
    setCsrf(data.csrf);
    setUser(null);
}

/** Atualiza só o número de solicitações pendentes. */
export async function refreshPending() {
    if (!currentUser) return;
    try {
        const data = await api.get('auth.php', { action: 'me' });
        if (data.user) {
            currentUser = data.user;
            renderHeader();
        } else {
            setUser(null);
        }
    } catch (e) { /* silencioso */ }
}

function renderHeader() {
    const user = currentUser;
    document.body.classList.toggle('is-logged', Boolean(user));
    document.querySelectorAll('.guest-only').forEach(el => { el.hidden = Boolean(user); });
    document.querySelectorAll('.user-only').forEach(el => { el.hidden = !user; });

    if (!user) return;

    document.querySelectorAll('[data-user-avatar]').forEach(el => paintAvatar(el, user));
    document.querySelectorAll('[data-user-name]').forEach(el => { el.textContent = user.name; });
    document.querySelectorAll('[data-user-firstname]').forEach(el => { el.textContent = user.name.split(' ')[0]; });
    document.querySelectorAll('[data-user-email]').forEach(el => { el.textContent = user.email; });
    document.querySelectorAll('[data-user-since]').forEach(el => { el.textContent = 'Membro desde ' + formatDate(user.created_at); });
    document.querySelectorAll('[data-pending-badge]').forEach(el => {
        el.textContent = user.pending;
        el.hidden = !user.pending;
    });
}
