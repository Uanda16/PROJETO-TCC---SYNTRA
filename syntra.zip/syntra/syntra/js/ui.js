/* ==========================================================
   Utilidades de interface
   ========================================================== */

/** Escapa texto para inserir com segurança em HTML. */
export function esc(value) {
    return String(value ?? '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

/** Minúsculas e sem acentos (igual ao normalize_text do PHP). */
export function normalize(text) {
    return String(text ?? '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').trim();
}

/* ---------- Avatar com iniciais ---------- */

const AVATAR_COLORS = [
    ['#7c3aed', '#a78bfa'], ['#4f46e5', '#818cf8'], ['#2563eb', '#60a5fa'],
    ['#0891b2', '#22d3ee'], ['#9333ea', '#e879f9'], ['#db2777', '#f472b6'],
];

export function initials(name) {
    const parts = String(name || '?').trim().split(/\s+/);
    const first = parts[0]?.[0] || '?';
    const last = parts.length > 1 ? parts[parts.length - 1][0] : '';
    return (first + last).toUpperCase();
}

export function avatarStyle(id) {
    const [a, b] = AVATAR_COLORS[(Number(id) || 0) % AVATAR_COLORS.length];
    return `background:linear-gradient(135deg, ${a}, ${b})`;
}

export function avatarHtml(user, size = '') {
    return `<span class="avatar ${size ? 'avatar--' + size : ''}" style="${avatarStyle(user.id)}">${esc(initials(user.name))}</span>`;
}

export function paintAvatar(element, user) {
    element.textContent = initials(user.name);
    element.setAttribute('style', avatarStyle(user.id));
}

/* ---------- Datas ---------- */

export function formatDate(value, withTime = false) {
    if (!value) return '';
    const date = new Date(String(value).replace(' ', 'T'));
    if (Number.isNaN(date.getTime())) return '';
    const options = { day: '2-digit', month: 'short', year: 'numeric' };
    if (withTime) Object.assign(options, { hour: '2-digit', minute: '2-digit' });
    return date.toLocaleDateString('pt-BR', options);
}

export function timeAgo(value) {
    const date = new Date(String(value).replace(' ', 'T'));
    const seconds = Math.round((Date.now() - date.getTime()) / 1000);
    if (seconds < 60) return 'agora mesmo';
    const minutes = Math.round(seconds / 60);
    if (minutes < 60) return `há ${minutes} min`;
    const hours = Math.round(minutes / 60);
    if (hours < 24) return `há ${hours} h`;
    const days = Math.round(hours / 24);
    if (days < 30) return `há ${days} dia${days > 1 ? 's' : ''}`;
    return formatDate(value);
}

/* ---------- Avisos (toasts) ---------- */

export function toast(message, type = 'success') {
    const area = document.querySelector('[data-toasts]');
    if (!area) return;
    const item = document.createElement('div');
    item.className = `toast toast--${type}`;
    item.setAttribute('role', type === 'error' ? 'alert' : 'status');
    item.textContent = message;
    area.appendChild(item);
    requestAnimationFrame(() => item.classList.add('is-visible'));
    setTimeout(() => {
        item.classList.remove('is-visible');
        setTimeout(() => item.remove(), 300);
    }, 4200);
}

/* ---------- Formulários ---------- */

export function formData(form) {
    const data = {};
    new FormData(form).forEach((value, key) => { data[key] = value; });
    form.querySelectorAll('input[type=checkbox][name]').forEach(input => { data[input.name] = input.checked; });
    return data;
}

export function clearErrors(form) {
    form.querySelectorAll('.field.has-error').forEach(field => field.classList.remove('has-error'));
    form.querySelectorAll('.field-error').forEach(el => { el.textContent = ''; });
    const alert = form.querySelector('[data-form-alert]');
    if (alert) {
        alert.hidden = true;
        alert.className = 'form-alert';
    }
}

/** Mostra a mensagem geral e os erros de cada campo vindos da API. */
export function showErrors(form, error) {
    const fields = error.fields || {};
    let firstInvalid = null;

    Object.entries(fields).forEach(([name, message]) => {
        const input = form.querySelector(`[name="${name}"]`);
        const field = input?.closest('.field');
        if (!field) return;
        field.classList.add('has-error');
        const holder = field.querySelector('.field-error');
        if (holder) holder.textContent = message;
        firstInvalid ??= input;
    });

    const hasFieldMessages = Object.keys(fields).some(name => form.querySelector(`[name="${name}"]`));
    if (!hasFieldMessages || !firstInvalid) {
        formAlert(form, error.message, 'error');
    }
    // Foca depois que o formulário for destravado
    if (firstInvalid) setTimeout(() => firstInvalid.focus(), 0);
}

export function formAlert(form, message, type = 'error') {
    const alert = form.querySelector('[data-form-alert]');
    if (!alert) {
        toast(message, type);
        return;
    }
    alert.textContent = message;
    alert.className = `form-alert form-alert--${type}`;
    alert.hidden = false;
}

/**
 * Mostra "carregando" no botão e trava o formulário enquanto a tarefa roda,
 * para que nada seja editado no meio do envio.
 */
export async function withLoading(button, task) {
    if (!button) return task();
    const original = button.innerHTML;
    const form = button.closest('form');
    const fields = form
        ? [...form.elements].filter(el => !el.disabled && el !== button)
        : [];

    button.disabled = true;
    button.classList.add('is-loading');
    fields.forEach(el => { el.disabled = true; });
    form?.setAttribute('aria-busy', 'true');

    try {
        return await task();
    } finally {
        fields.forEach(el => { el.disabled = false; });
        form?.removeAttribute('aria-busy');
        button.disabled = false;
        button.classList.remove('is-loading');
        button.innerHTML = original;
    }
}

/* ---------- Chips de habilidades ---------- */

export function chipsHtml(skills, kind, highlight = '') {
    const term = normalize(highlight);
    return skills.map(skill => {
        const match = term && normalize(skill).includes(term);
        return `<span class="chip chip--${kind}${match ? ' chip--match' : ''}">${esc(skill)}</span>`;
    }).join('');
}
