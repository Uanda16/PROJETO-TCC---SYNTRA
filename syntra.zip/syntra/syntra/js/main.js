/* ==========================================================
   SYNTRA - Ponto de entrada do JavaScript
   ========================================================== */

import { api } from './api.js';
import { loadSession, onUserChange, isLogged, getUser, refreshPending } from './session.js';
import { initModals, openModal } from './modals.js';
import { route, startRouter, navigate, setAfterLogin } from './router.js';
import { initAuth } from './auth.js';
import { initConnect, initSkillSuggestions } from './components.js';
import { initExplorar } from './pages/explorar.js';
import { initPerfil } from './pages/perfil.js';
import { initConexoes } from './pages/conexoes.js';
import { initUsuario } from './pages/usuario.js';
import { initRedefinir } from './pages/redefinir.js';
import { initHeroSlider } from './slider.js';
import { toast } from './ui.js';

document.addEventListener('DOMContentLoaded', async () => {
    initModals();
    initAuth();
    initConnect();
    initExplorar();
    initPerfil();
    initConexoes();
    initUsuario();
    initRedefinir();
    initHeroSlider();
    initHomeActions();
    initSobre();
    initContactPrefill();

    try {
        await loadSession();
    } catch (error) {
        toast(error.message, 'error');
    }

    initSkillSuggestions();
    startRouter();

    // Confere novas solicitações de conexão a cada minuto
    setInterval(() => {
        if (isLogged() && document.visibilityState === 'visible') refreshPending();
    }, 60000);
});

/* ---------- Botões da página inicial ---------- */
function initHomeActions() {
    // Busca do topo -> página Explorar
    document.querySelector('[data-hero-search]').addEventListener('submit', event => {
        event.preventDefault();
        const q = event.target.q.value.trim();
        navigate('#explorar' + (q ? '?q=' + encodeURIComponent(q) : ''));
    });

    // "Começar agora": visitante -> cadastro; logado -> explorar
    document.addEventListener('click', event => {
        if (!event.target.closest('[data-start]')) return;
        if (isLogged()) {
            const user = getUser();
            navigate(user.teach.length || user.learn.length ? '#explorar' : '#perfil?secao=habilidades');
        } else {
            setAfterLogin('#perfil?secao=habilidades');
            openModal('register');
        }
    });

    // "Quero compartilhar": visitante -> cadastro primeiro
    document.querySelector('[data-share-card]').addEventListener('click', event => {
        if (isLogged()) return;
        event.preventDefault();
        setAfterLogin('#perfil?secao=habilidades');
        openModal('register');
    });

    // Link "Voltar"
    document.addEventListener('click', event => {
        if (event.target.closest('[data-back]') && history.length > 1) {
            event.preventDefault();
            history.back();
        }
    });
}

/* ---------- Números na página Sobre ---------- */
function initSobre() {
    route('sobre', async () => {
        try {
            const stats = await api.get('stats.php');
            const box = document.querySelector('[data-stats]');
            ['users', 'skills', 'connections'].forEach(key => {
                box.querySelector(`[data-stat="${key}"]`).textContent = stats[key].toLocaleString('pt-BR');
            });
            box.hidden = stats.users === 0;
        } catch (e) { /* opcional */ }
    });
}

/* ---------- Formulário de contato já preenchido para quem está logado ---------- */
function initContactPrefill() {
    onUserChange(user => {
        document.querySelectorAll('[data-prefill]').forEach(input => {
            if (user && !input.value) input.value = user[input.dataset.prefill] || '';
        });
    });
}
