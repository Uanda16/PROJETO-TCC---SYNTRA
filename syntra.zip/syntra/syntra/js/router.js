/* ==========================================================
   Rotas pelo "#" da URL
   Exemplos: #inicio  #explorar?q=python&tipo=teach  #usuario/12  #redefinir/TOKEN
   ========================================================== */

import { isLogged } from './session.js';
import { openModal } from './modals.js';

const handlers = {};
let current = { page: '', param: '', query: new URLSearchParams() };
let pendingAfterLogin = null;

/** Registra o que fazer ao abrir uma página. */
export function route(page, handler) {
    handlers[page] = handler;
}

export function currentRoute() {
    return current;
}

export function navigate(hash) {
    if (location.hash === hash) {
        render();
    } else {
        location.hash = hash;
    }
}

/** Depois que a pessoa entrar, leva para esta página. */
export function setAfterLogin(hash) {
    pendingAfterLogin = hash;
}

export function consumeAfterLogin() {
    const hash = pendingAfterLogin;
    pendingAfterLogin = null;
    return hash;
}

function parse() {
    const raw = decodeURIComponent(location.hash.slice(1));
    const [path, queryString = ''] = raw.split('?');
    const [page, ...rest] = path.split('/');
    return {
        page: page || 'inicio',
        param: rest.join('/'),
        query: new URLSearchParams(queryString),
    };
}

export function render() {
    const next = parse();
    let section = document.querySelector(`.page-section[data-page="${CSS.escape(next.page)}"]`);

    if (!section) {
        section = document.querySelector('.page-section[data-page="nao-encontrada"]');
        next.page = 'nao-encontrada';
    }

    // Páginas que exigem login
    if (section.hasAttribute('data-auth') && !isLogged()) {
        setAfterLogin(location.hash);
        history.replaceState(null, '', '#inicio');
        showSection('inicio');
        openModal('login', 'Entre na sua conta para continuar.');
        return;
    }

    const pageChanged = next.page !== current.page || next.param !== current.param;
    current = next;
    showSection(next.page);

    if (pageChanged) {
        window.scrollTo({ top: 0 });
    }
    handlers[next.page]?.(next);
}

function showSection(page) {
    document.querySelectorAll('.page-section').forEach(section => {
        section.classList.toggle('active-page', section.dataset.page === page);
    });
    document.querySelectorAll('.main-nav a[data-nav]').forEach(link => {
        const active = link.dataset.nav === page;
        link.classList.toggle('active', active);
        if (active) link.setAttribute('aria-current', 'page');
        else link.removeAttribute('aria-current');
    });
}

export function startRouter() {
    window.addEventListener('hashchange', render);
    render();
}
