/* ==========================================================
   Componentes reutilizados: cartão de usuário, botão "Conectar"
   e sugestões de habilidades
   ========================================================== */

import { api } from './api.js';
import { getUser } from './session.js';
import { openModal, onModalOpen, closeModal } from './modals.js';
import { requireLogin } from './auth.js';
import { esc, avatarHtml, chipsHtml, formData, clearErrors, showErrors, withLoading, toast } from './ui.js';

const userCache = new Map();   // usuários mostrados na tela (para o modal de conexão)

export function cacheUser(user) {
    userCache.set(Number(user.id), user);
}

/* ---------- Cartão de usuário ---------- */

export function userCardHtml(user, highlight = '') {
    cacheUser(user);
    const meta = [user.course, user.city].filter(Boolean).map(esc).join(' &middot; ');
    return `
        <article class="user-card">
            <a href="#usuario/${user.id}" class="user-card__head">
                ${avatarHtml(user, 'md')}
                <span>
                    <strong>${esc(user.name)}</strong>
                    ${meta ? `<small>${meta}</small>` : ''}
                </span>
            </a>
            ${user.bio ? `<p class="user-card__bio">${esc(user.bio)}</p>` : ''}
            ${user.teach.length ? `
                <div class="skill-group">
                    <span class="skill-group__label">Ensina</span>
                    <div class="chips">${chipsHtml(user.teach, 'teach', highlight)}</div>
                </div>` : ''}
            ${user.learn.length ? `
                <div class="skill-group">
                    <span class="skill-group__label">Quer aprender</span>
                    <div class="chips">${chipsHtml(user.learn, 'learn', highlight)}</div>
                </div>` : ''}
            <div class="user-card__actions">
                <a href="#usuario/${user.id}" class="btn btn-outline btn-sm">Ver perfil</a>
                ${connectButtonHtml(user)}
            </div>
        </article>`;
}

/* ---------- Botão de conexão conforme a situação ---------- */

export function connectButtonHtml(user) {
    const me = getUser();
    const id = Number(user.id);
    const conn = user.connection;
    const attrs = `data-connect-slot="${id}"`;

    if (me && me.id === id) {
        return `<a href="#perfil" class="btn btn-outline btn-sm" ${attrs}>Editar meu perfil</a>`;
    }
    if (!conn || (conn.status === 'declined' && conn.direction === 'received')) {
        return `<button type="button" class="btn btn-gradient btn-sm" data-connect-id="${id}" ${attrs}>Conectar</button>`;
    }
    if (conn.status === 'accepted') {
        return `<a href="#usuario/${id}" class="btn btn-success btn-sm" ${attrs}>&#10003; Conectados</a>`;
    }
    if (conn.status === 'pending' && conn.direction === 'received') {
        return `<a href="#conexoes" class="btn btn-gradient btn-sm" ${attrs}>Responder solicitação</a>`;
    }
    if (conn.status === 'pending') {
        return `<button type="button" class="btn btn-muted btn-sm" disabled ${attrs}>Solicitação enviada</button>`;
    }
    return `<button type="button" class="btn btn-muted btn-sm" disabled ${attrs}>Não aceitou</button>`;
}

function refreshConnectButtons(userId) {
    const user = userCache.get(Number(userId));
    if (!user) return;
    document.querySelectorAll(`[data-connect-slot="${userId}"]`).forEach(slot => {
        slot.outerHTML = connectButtonHtml(user);
    });
}

/* ---------- Modal "Conectar" ---------- */

export function initConnect() {
    const form = document.querySelector('[data-connect-form]');

    document.addEventListener('click', event => {
        const button = event.target.closest('[data-connect-id]');
        if (!button) return;
        const id = Number(button.dataset.connectId);
        if (!requireLogin(location.hash, 'Entre na sua conta para se conectar com outras pessoas.')) return;
        openModal('connect', userCache.get(id));
    });

    onModalOpen('connect', (modal, user) => {
        form.reset();
        form.user_id.value = user.id;
        modal.querySelector('[data-connect-name]').textContent = user.name.split(' ')[0];

        // Sugere primeiro as habilidades que a pessoa ensina e eu quero aprender
        const myLearn = new Set((getUser()?.learn || []).map(s => s.toLowerCase()));
        const teach = [...user.teach].sort((a, b) => myLearn.has(b.toLowerCase()) - myLearn.has(a.toLowerCase()));
        const select = form.skill;
        select.innerHTML = '<option value="">Conversa geral</option>'
            + teach.map(skill => `<option value="${esc(skill)}">${esc(skill)}</option>`).join('');
        if (teach.length && myLearn.has(teach[0].toLowerCase())) select.value = teach[0];
        modal.querySelector('[data-connect-skill-field]').hidden = teach.length === 0;
    });

    form.addEventListener('submit', async event => {
        event.preventDefault();
        clearErrors(form);
        const data = formData(form);
        await withLoading(form.querySelector('[type=submit]'), async () => {
            try {
                const result = await api.post('connections.php?action=request', {
                    user_id: Number(data.user_id), skill: data.skill, message: data.message,
                });
                closeModal('connect');
                toast(result.message);
                const user = userCache.get(Number(data.user_id));
                if (user) {
                    user.connection = { status: 'pending', direction: 'sent' };
                    refreshConnectButtons(user.id);
                }
            } catch (error) {
                showErrors(form, error);
            }
        });
    });
}

/* ---------- Sugestões de habilidades (datalist) ---------- */

export function initSkillSuggestions() {
    const datalist = document.getElementById('skills-suggestions');
    let timer;
    let lastQuery = null;

    async function load(query) {
        if (query === lastQuery) return;
        lastQuery = query;
        try {
            const data = await api.get('skills.php', { q: query });
            datalist.innerHTML = data.skills.map(skill => `<option value="${esc(skill)}"></option>`).join('');
        } catch (e) { /* sem sugestões */ }
    }

    document.addEventListener('input', event => {
        if (event.target.getAttribute('list') !== 'skills-suggestions') return;
        clearTimeout(timer);
        const value = event.target.value.trim();
        timer = setTimeout(() => load(value), 200);
    });

    load('');
}
