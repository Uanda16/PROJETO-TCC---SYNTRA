/* ==========================================================
   Comunicação com a API PHP (pasta api/)
   ========================================================== */

let csrfToken = '';

export function setCsrf(token) {
    if (token) csrfToken = token;
}

export class ApiError extends Error {
    constructor(message, status = 0, fields = {}) {
        super(message);
        this.status = status;
        this.fields = fields;
    }
}

async function request(method, path, { params, body } = {}, retry = true) {
    let url = 'api/' + path;
    if (params) {
        const query = new URLSearchParams();
        Object.entries(params).forEach(([key, value]) => {
            if (value !== undefined && value !== null && value !== '') query.set(key, value);
        });
        const qs = query.toString();
        if (qs) url += (url.includes('?') ? '&' : '?') + qs;
    }

    const options = {
        method,
        credentials: 'same-origin',
        headers: { 'Accept': 'application/json' },
    };
    if (method !== 'GET') {
        options.headers['Content-Type'] = 'application/json';
        options.headers['X-CSRF-Token'] = csrfToken;
        options.body = JSON.stringify(body || {});
    }

    let response;
    try {
        response = await fetch(url, options);
    } catch (e) {
        throw new ApiError('Sem conexão com o servidor. Verifique sua internet.');
    }

    let data;
    try {
        data = await response.json();
    } catch (e) {
        throw new ApiError(
            response.ok
                ? 'Resposta inválida do servidor.'
                : 'O servidor PHP não respondeu corretamente. O site precisa estar rodando em um servidor com PHP (ex.: XAMPP).',
            response.status
        );
    }

    if (data.csrf) setCsrf(data.csrf);

    // Token expirado: busca um novo e tenta mais uma vez
    if (response.status === 419 && retry) {
        const me = await request('GET', 'auth.php', { params: { action: 'me' } }, false);
        setCsrf(me.csrf);
        return request(method, path, { params, body }, false);
    }

    if (!response.ok || data.ok === false) {
        throw new ApiError(data.error || 'Algo deu errado.', response.status, data.fields || {});
    }
    return data;
}

export const api = {
    get: (path, params) => request('GET', path, { params }),
    post: (path, body) => request('POST', path, { body }),
};
