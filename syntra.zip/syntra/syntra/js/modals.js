/* ==========================================================
   Janelas (modais) com o elemento <dialog>
   ========================================================== */

import { clearErrors, formAlert } from './ui.js';

const openers = {};   // funções que preparam um modal antes de abrir

export function onModalOpen(name, callback) {
    openers[name] = callback;
}

export function getModal(name) {
    return document.querySelector(`dialog[data-modal="${name}"]`);
}

/**
 * Abre um modal (fechando o que estiver aberto).
 * @param {string} name
 * @param {string|object} [info] mensagem de aviso ou dados para o preparador
 */
export function openModal(name, info) {
    const modal = getModal(name);
    if (!modal) return;

    document.querySelectorAll('dialog[open]').forEach(other => {
        if (other !== modal) other.close();
    });

    modal.querySelectorAll('form').forEach(form => clearErrors(form));
    openers[name]?.(modal, info);

    if (!modal.open) modal.showModal();

    if (typeof info === 'string') {
        const form = modal.querySelector('form');
        if (form) formAlert(form, info, 'info');
    }

    // Foco imediato no primeiro campo (sem atraso, para não "roubar" o foco
    // de um campo que a pessoa já tenha clicado)
    modal.querySelector('input:not([type=hidden]), select, textarea')?.focus();
}

export function closeModal(name) {
    const modal = name ? getModal(name) : document.querySelector('dialog[open]');
    modal?.close();
}

export function initModals() {
    document.addEventListener('click', event => {
        const opener = event.target.closest('[data-open-modal]');
        if (opener) {
            event.preventDefault();
            openModal(opener.dataset.openModal);
            return;
        }
        if (event.target.closest('[data-close-modal]')) {
            const modal = event.target.closest('dialog');
            modal?.close();
            return;
        }
    });

    // Clique fora da caixa fecha o modal
    document.querySelectorAll('dialog.modal').forEach(modal => {
        modal.addEventListener('mousedown', event => {
            if (event.target !== modal) return;
            const box = modal.getBoundingClientRect();
            const inside = event.clientX >= box.left && event.clientX <= box.right
                && event.clientY >= box.top && event.clientY <= box.bottom;
            if (!inside) modal.close();
        });
    });

    // Botão "Mostrar senha"
    document.addEventListener('click', event => {
        const toggle = event.target.closest('[data-toggle-password]');
        if (!toggle) return;
        const input = toggle.parentElement.querySelector('input');
        const show = input.type === 'password';
        input.type = show ? 'text' : 'password';
        toggle.textContent = show ? 'Ocultar' : 'Mostrar';
        toggle.setAttribute('aria-label', show ? 'Ocultar senha' : 'Mostrar senha');
    });
}
