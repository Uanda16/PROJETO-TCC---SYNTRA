/* ==========================================================
   Entrar, cadastrar, esqueci a senha, sair e menu do usuário
   ========================================================== */

import { api } from './api.js';
import { setUser, logout, getUser } from './session.js';
import { closeModal, openModal, onModalOpen } from './modals.js';
import { navigate, render, consumeAfterLogin, setAfterLogin } from './router.js';
import { formData, clearErrors, showErrors, formAlert, withLoading, toast } from './ui.js';

export function initAuth() {
    const loginForm = document.querySelector('[data-login-form]');
    const registerForm = document.querySelector('[data-register-form]');
    const forgotForm = document.querySelector('[data-forgot-form]');
    const deleteForm = document.querySelector('[data-delete-form]');

    /* ---------- Entrar ---------- */
    loginForm.addEventListener('submit', async event => {
        event.preventDefault();
        clearErrors(loginForm);
        const data = formData(loginForm);
        if (!data.email || !data.password) {
            formAlert(loginForm, 'Informe e-mail e senha.');
            return;
        }
        await withLoading(loginForm.querySelector('[type=submit]'), async () => {
            try {
                const result = await api.post('auth.php?action=login', data);
                loginForm.reset();
                closeModal('login');
                setUser(result.user);
                toast(`Olá, ${result.user.name.split(' ')[0]}!`);
                goAfterLogin();
            } catch (error) {
                showErrors(loginForm, error);
                loginForm.querySelector('[name=password]').value = '';
            }
        });
    });

    /* ---------- Cadastrar ---------- */
    registerForm.addEventListener('submit', async event => {
        event.preventDefault();
        clearErrors(registerForm);
        const data = formData(registerForm);

        // Verificações rápidas antes de enviar (o servidor confere de novo)
        const errors = {};
        if (data.name.trim().length < 3) errors.name = 'Informe seu nome completo.';
        if (!/^\S+@\S+\.\S+$/.test(data.email)) errors.email = 'Informe um e-mail válido.';
        if (data.password.length < 8 || !/[A-Za-z]/.test(data.password) || !/\d/.test(data.password)) {
            errors.password = 'Mínimo de 8 caracteres, com letras e números.';
        } else if (data.password !== data.password_confirm) {
            errors.password_confirm = 'As senhas não conferem.';
        }
        if (!data.terms) errors.terms = 'É preciso aceitar os termos de uso.';
        if (Object.keys(errors).length) {
            showErrors(registerForm, { message: 'Confira os campos destacados.', fields: errors });
            return;
        }

        await withLoading(registerForm.querySelector('[type=submit]'), async () => {
            try {
                const result = await api.post('auth.php?action=register', data);
                registerForm.reset();
                closeModal('register');
                setUser(result.user);
                toast('Conta criada! Agora cadastre suas habilidades.');
                const target = consumeAfterLogin();
                navigate(target && !target.startsWith('#perfil') ? target : '#perfil?secao=habilidades');
            } catch (error) {
                showErrors(registerForm, error);
            }
        });
    });

    /* ---------- Esqueci a senha ---------- */
    onModalOpen('forgot', modal => {
        const email = document.querySelector('[data-login-form] [name=email]').value;
        if (email) modal.querySelector('[name=email]').value = email;
    });

    forgotForm.addEventListener('submit', async event => {
        event.preventDefault();
        clearErrors(forgotForm);
        const data = formData(forgotForm);   // lê antes de travar o formulário
        await withLoading(forgotForm.querySelector('[type=submit]'), async () => {
            try {
                const result = await api.post('auth.php?action=forgot', data);
                formAlert(forgotForm, result.message, 'success');
                if (result.dev_link) {
                    const alert = forgotForm.querySelector('[data-form-alert]');
                    const link = document.createElement('a');
                    link.href = result.dev_link;
                    link.textContent = 'Abrir link de redefinição';
                    link.className = 'dev-link';
                    link.addEventListener('click', () => closeModal('forgot'));
                    alert.append(document.createElement('br'), link);
                }
            } catch (error) {
                showErrors(forgotForm, error);
            }
        });
    });

    /* ---------- Excluir conta ---------- */
    deleteForm.addEventListener('submit', async event => {
        event.preventDefault();
        clearErrors(deleteForm);
        const data = formData(deleteForm);   // lê antes de travar o formulário
        await withLoading(deleteForm.querySelector('[type=submit]'), async () => {
            try {
                const result = await api.post('profile.php?action=delete', data);
                deleteForm.reset();
                closeModal('delete');
                setUser(null);
                toast(result.message);
                navigate('#inicio');
            } catch (error) {
                showErrors(deleteForm, error);
            }
        });
    });

    /* ---------- Sair ---------- */
    document.addEventListener('click', async event => {
        if (!event.target.closest('[data-logout]')) return;
        closeUserMenu();
        try {
            await logout();
            toast('Você saiu da sua conta.');
            navigate('#inicio');
        } catch (error) {
            toast(error.message, 'error');
        }
    });

    initUserMenu();
}

/** Abre o login e, depois de entrar, vai para a página indicada. */
export function requireLogin(afterHash, message = 'Entre na sua conta para continuar.') {
    if (getUser()) return true;
    if (afterHash) setAfterLogin(afterHash);
    openModal('login', message);
    return false;
}

function goAfterLogin() {
    const target = consumeAfterLogin();
    if (target) navigate(target);
    else render();   // atualiza a página atual (ex.: botões "Conectar")
}

/* ---------- Menu do usuário ---------- */

function initUserMenu() {
    const toggle = document.querySelector('[data-user-menu-toggle]');
    const panel = document.querySelector('[data-user-menu]');

    toggle.addEventListener('click', () => {
        const open = panel.hidden;
        panel.hidden = !open;
        toggle.setAttribute('aria-expanded', String(open));
    });

    document.addEventListener('click', event => {
        if (!event.target.closest('.user-menu')) closeUserMenu();
        if (event.target.closest('[data-user-menu] a')) closeUserMenu();
    });

    document.addEventListener('keydown', event => {
        if (event.key === 'Escape') closeUserMenu();
    });
}

function closeUserMenu() {
    const panel = document.querySelector('[data-user-menu]');
    const toggle = document.querySelector('[data-user-menu-toggle]');
    if (panel && !panel.hidden) {
        panel.hidden = true;
        toggle.setAttribute('aria-expanded', 'false');
    }
}
