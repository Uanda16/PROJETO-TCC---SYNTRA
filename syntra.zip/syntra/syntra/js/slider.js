/* ==========================================================
   Carrossel das imagens laterais do hero
   Cada <figure> tem sua própria lista em data-slides.
   As setas avançam todas as listas juntas.
   ========================================================== */

export function initHeroSlider() {
    const slider = document.querySelector('[data-slider]');
    if (!slider) return;

    const figures = [...slider.querySelectorAll('.hero-figure[data-slides]')].map(figure => {
        let slides = [];
        try { slides = JSON.parse(figure.dataset.slides); } catch (e) { /* lista inválida */ }
        slides.forEach(src => { new Image().src = src; }); // pré-carrega
        return { img: figure.querySelector('img'), slides };
    });

    const total = Math.max(0, ...figures.map(f => f.slides.length));
    if (total <= 1) {
        slider.querySelectorAll('.hero-arrow').forEach(btn => { btn.hidden = true; });
        return;
    }

    let current = 0;

    function show(index) {
        current = (index + total) % total;
        figures.forEach(({ img, slides }) => {
            if (slides.length <= 1) return;
            const nextSrc = slides[current % slides.length];
            if (img.getAttribute('src') === nextSrc) return;
            img.classList.add('is-fading');
            setTimeout(() => {
                img.src = nextSrc;
                img.classList.remove('is-fading');
            }, 300);
        });
    }

    slider.querySelector('[data-slider-prev]')?.addEventListener('click', () => show(current - 1));
    slider.querySelector('[data-slider-next]')?.addEventListener('click', () => show(current + 1));
}
