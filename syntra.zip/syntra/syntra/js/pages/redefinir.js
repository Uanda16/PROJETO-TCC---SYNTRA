/* ==========================================================
   Página Redefinir senha (#redefinir/TOKEN, link enviado por e-mail)
   ========================================================== */

import { api } from '../api.js';
import { route, navigate } from '../router.js';
import { setUser } from '../session.js';
import { formData, clearErrors, showErrors, withLoading, toast } from '../ui.js';

export function initRedefinir() {
    const form = document.querySelector('[data-reset-form]');
    const invalid = document.querySelector('[data-reset-invalid]');
    let token = '';

    route('redefinir', async ({ param }) => {
        token = param;
        form.hidden = true;
        invalid.hidden = true;
        clearErrors(form);
        form.reset();

        try {
            const { valid } = await api.get('auth.php', { action: 'reset_check', token });
            form.hidden = !valid;
            invalid.hidden = valid;
            if (valid) form.password.focus();
        } catch (error) {
            invalid.hidden = false;
        }
    });

    form.addEventListener('submit', async event => {
        event.preventDefault();
        clearErrors(form);
        const data = formData(form);   // lê antes de travar o formulário
        await withLoading(form.querySelector('[type=submit]'), async () => {
            try {
                const result = await api.post('auth.php?action=reset', { ...data, token });
                setUser(result.user);
                toast('Senha alterada! Você já está conectado.');
                history.replaceState(null, '', '#inicio');   // remove o token da URL
                navigate('#explorar');
            } catch (error) {
                if (error.status === 410) {
                    form.hidden = true;
                    invalid.hidden = false;
                }
                showErrors(form, error);
            }
        });
    });
}
