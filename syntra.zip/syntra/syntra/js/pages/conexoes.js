/* ==========================================================
   Página Conexões: recebidas, conectados e enviadas
   ========================================================== */

import { api } from '../api.js';
import { route } from '../router.js';
import { refreshPending } from '../session.js';
import { esc, avatarHtml, chipsHtml, timeAgo, withLoading, toast } from '../ui.js';

let data = { received: [], accepted: [], sent: [] };
let activeTab = 'received';

export function initConexoes() {
    const list = document.querySelector('[data-connection-list]');

    document.querySelectorAll('[data-tab]').forEach(tab => {
        tab.addEventListener('click', () => {
            activeTab = tab.dataset.tab;
            render();
        });
    });

    list.addEventListener('click', async event => {
        const button = event.target.closest('[data-action]');
        if (!button) return;

        const { action, id } = button.dataset;
        if (action === 'remove' && !confirm('Desfazer esta conexão? Vocês deixarão de ver o e-mail um do outro.')) return;

        const body = { id: Number(id) };
        let endpoint = action;
        if (action === 'accept' || action === 'decline') {
            endpoint = 'respond';
            body.accept = action === 'accept';
        }

        await withLoading(button, async () => {
            try {
                const result = await api.post(`connections.php?action=${endpoint}`, body);
                data = { received: result.received, accepted: result.accepted, sent: result.sent };
                if (action === 'accept') activeTab = 'accepted';
                render();
                toast(result.message);
                refreshPending();
            } catch (error) {
                toast(error.message, 'error');
            }
        });
    });

    route('conexoes', () => load());
}

async function load() {
    const list = document.querySelector('[data-connection-list]');
    list.innerHTML = '<div class="user-card user-card--skeleton"></div>';
    try {
        const result = await api.get('connections.php');
        data = { received: result.received, accepted: result.accepted, sent: result.sent };
        // Abre direto na aba com novidades
        if (activeTab === 'received' && !data.received.length && data.accepted.length) activeTab = 'accepted';
        render();
        refreshPending();
    } catch (error) {
        list.innerHTML = `<div class="empty-state empty-state--error"><p>${esc(error.message)}</p></div>`;
    }
}

function render() {
    document.querySelectorAll('[data-tab]').forEach(tab => {
        const active = tab.dataset.tab === activeTab;
        tab.classList.toggle('is-active', active);
        tab.setAttribute('aria-selected', String(active));
    });
    Object.keys(data).forEach(key => {
        const badge = document.querySelector(`[data-count="${key}"]`);
        badge.textContent = data[key].length;
        badge.classList.toggle('badge--muted', key !== 'received' || data[key].length === 0);
    });

    const items = data[activeTab];
    const list = document.querySelector('[data-connection-list]');

    if (!items.length) {
        const empty = {
            received: ['Nenhuma solicitação nova', 'Quando alguém quiser se conectar com você, aparece aqui.'],
            accepted: ['Você ainda não tem conexões', 'Encontre pessoas e envie uma solicitação.'],
            sent: ['Nenhuma solicitação enviada', 'Explore e conecte-se com quem ensina o que você quer aprender.'],
        }[activeTab];
        list.innerHTML = `<div class="empty-state"><h3>${empty[0]}</h3><p>${empty[1]}</p>
            <a href="#explorar" class="btn btn-gradient">Explorar pessoas</a></div>`;
        return;
    }

    list.innerHTML = items.map(item => itemHtml(item)).join('');
}

function itemHtml(item) {
    const user = item.user;
    const meta = [user.course, user.city].filter(Boolean).map(esc).join(' &middot; ');
    const about = item.skill ? `sobre <strong>${esc(item.skill)}</strong>` : '';

    let header = '';
    let actions = '';

    if (activeTab === 'received') {
        header = `quer se conectar com você ${about}`;
        actions = `
            <button type="button" class="btn btn-gradient btn-sm" data-action="accept" data-id="${item.id}">Aceitar</button>
            <button type="button" class="btn btn-outline btn-sm" data-action="decline" data-id="${item.id}">Recusar</button>`;
    } else if (activeTab === 'accepted') {
        header = `conectados ${about}`;
        actions = `
            <a class="btn btn-gradient btn-sm" href="mailto:${esc(user.email)}?subject=${encodeURIComponent('SYNTRA - ' + (item.skill || 'Troca de conhecimento'))}">Enviar e-mail</a>
            <button type="button" class="btn btn-outline btn-sm" data-action="remove" data-id="${item.id}">Desfazer</button>`;
    } else {
        header = item.status === 'declined' ? 'não aceitou sua solicitação' : `solicitação enviada ${about}`;
        actions = item.status === 'pending'
            ? `<button type="button" class="btn btn-outline btn-sm" data-action="cancel" data-id="${item.id}">Cancelar</button>`
            : '<span class="status status--declined">Recusada</span>';
    }

    return `
        <article class="connection-item">
            <a href="#usuario/${user.id}" class="connection-item__avatar">${avatarHtml(user, 'md')}</a>
            <div class="connection-item__body">
                <p class="connection-item__title">
                    <a href="#usuario/${user.id}"><strong>${esc(user.name)}</strong></a> ${header}
                    <small>${timeAgo(item.date)}</small>
                </p>
                ${meta ? `<p class="connection-item__meta">${meta}</p>` : ''}
                ${item.message && activeTab !== 'sent' ? `<blockquote>${esc(item.message)}</blockquote>` : ''}
                ${activeTab === 'accepted' ? `<p class="connection-item__email">&#9993; <a href="mailto:${esc(user.email)}">${esc(user.email)}</a></p>` : ''}
                ${user.teach.length ? `<div class="chips chips--sm">${chipsHtml(user.teach.slice(0, 6), 'teach')}</div>` : ''}
            </div>
            <div class="connection-item__actions">${actions}</div>
        </article>`;
}
