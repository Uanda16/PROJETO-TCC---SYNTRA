/* ==========================================================
   Perfil público de um usuário (#usuario/ID)
   ========================================================== */

import { api } from '../api.js';
import { route } from '../router.js';
import { cacheUser, connectButtonHtml } from '../components.js';
import { esc, avatarHtml, chipsHtml, formatDate } from '../ui.js';

export function initUsuario() {
    route('usuario', async ({ param }) => {
        const box = document.querySelector('[data-public-profile]');
        box.innerHTML = '<div class="panel profile-public profile-public--loading"></div>';

        try {
            const { user } = await api.get('users.php', { id: param });
            cacheUser(user);
            box.innerHTML = profileHtml(user);
            document.title = `${user.name} - SYNTRA`;
        } catch (error) {
            box.innerHTML = `<div class="empty-state"><h3>${esc(error.message)}</h3>
                <a href="#explorar" class="btn btn-gradient">Explorar pessoas</a></div>`;
        }
    });

    // Restaura o título ao sair do perfil
    window.addEventListener('hashchange', () => {
        if (!location.hash.startsWith('#usuario')) document.title = 'SYNTRA - Conectando habilidades e conhecimentos';
    });
}

function profileHtml(user) {
    const meta = [user.course, user.city].filter(Boolean).map(esc).join(' &middot; ');
    const connected = user.connection?.status === 'accepted';

    return `
        <a href="#explorar" class="back-link" data-back>&larr; Voltar</a>
        <div class="panel profile-public">
            <div class="profile-public__head">
                ${avatarHtml(user, 'xl')}
                <div>
                    <h2>${esc(user.name)}</h2>
                    ${meta ? `<p class="profile-public__meta">${meta}</p>` : ''}
                    <p class="profile-public__since">Na SYNTRA desde ${formatDate(user.created_at)}</p>
                </div>
                <div class="profile-public__action">${connectButtonHtml(user)}</div>
            </div>

            ${user.email ? `
                <p class="profile-public__email">&#9993; <a href="mailto:${esc(user.email)}">${esc(user.email)}</a>
                ${connected ? '<small>Vocês estão conectados</small>' : ''}</p>` : ''}

            ${user.bio ? `<div class="profile-public__bio"><h3>Sobre</h3><p>${esc(user.bio)}</p></div>` : ''}

            <div class="profile-public__skills">
                <div>
                    <h3><span class="dot dot--purple"></span> Pode ensinar</h3>
                    ${user.teach.length ? `<div class="chips">${chipsHtml(user.teach, 'teach')}</div>` : '<p class="muted">Ainda não informou.</p>'}
                </div>
                <div>
                    <h3><span class="dot dot--blue"></span> Quer aprender</h3>
                    ${user.learn.length ? `<div class="chips">${chipsHtml(user.learn, 'learn')}</div>` : '<p class="muted">Ainda não informou.</p>'}
                </div>
            </div>
        </div>`;
}
