/* ==========================================================
   Página Explorar: busca de pessoas por habilidade
   ========================================================== */

import { api } from '../api.js';
import { route, navigate } from '../router.js';
import { userCardHtml } from '../components.js';
import { esc } from '../ui.js';

const TYPE_LABEL = {
    teach: ['ensina', 'ensinam'],
    learn: ['quer aprender', 'querem aprender'],
    all: null,
};

let state = { q: '', tipo: 'teach', page: 1, pages: 1 };
let requestId = 0;

export function initExplorar() {
    const form = document.querySelector('[data-explore-form]');
    const results = document.querySelector('[data-results]');
    const loadMore = document.querySelector('[data-load-more]');

    form.addEventListener('submit', event => {
        event.preventDefault();
        go(form.q.value.trim(), form.tipo.value);
    });

    form.addEventListener('change', event => {
        if (event.target.name === 'tipo') go(form.q.value.trim(), event.target.value);
    });

    loadMore.addEventListener('click', () => search(state.page + 1, true));

    document.querySelector('[data-popular-list]').addEventListener('click', event => {
        const chip = event.target.closest('[data-skill]');
        if (chip) go(chip.dataset.skill, form.tipo.value);
    });

    route('explorar', ({ query }) => {
        state.q = query.get('q') || '';
        state.tipo = ['teach', 'learn', 'all'].includes(query.get('tipo')) ? query.get('tipo') : 'teach';
        form.q.value = state.q;
        form.tipo.value = state.tipo;
        loadPopular();
        search(1, false);
    });

    function go(q, tipo) {
        const params = new URLSearchParams();
        if (q) params.set('q', q);
        if (tipo && tipo !== 'teach') params.set('tipo', tipo);
        const qs = params.toString();
        navigate('#explorar' + (qs ? '?' + qs : ''));
    }

    async function search(page, append) {
        const id = ++requestId;
        const info = document.querySelector('[data-results-info]');
        if (!append) {
            results.innerHTML = skeletons(6);
            info.textContent = '';
        }
        loadMore.disabled = true;

        try {
            const data = await api.get('search.php', { q: state.q, type: state.tipo, page });
            if (id !== requestId) return;   // resposta antiga

            state.page = data.page;
            state.pages = data.pages;

            const html = data.results.map(user => userCardHtml(user, state.q)).join('');
            if (append) results.insertAdjacentHTML('beforeend', html);
            else results.innerHTML = html || emptyState();

            const plural = data.total > 1;
            const verb = TYPE_LABEL[state.tipo];
            info.innerHTML = data.total
                ? `${data.total} pessoa${plural ? 's' : ''}${verb ? ' que ' + verb[plural ? 1 : 0] : ''}`
                  + (state.q ? ` &ldquo;<strong>${esc(state.q)}</strong>&rdquo;` : '')
                : '';
            loadMore.hidden = state.page >= state.pages;
        } catch (error) {
            if (id !== requestId) return;
            results.innerHTML = `<div class="empty-state empty-state--error"><p>${esc(error.message)}</p></div>`;
            loadMore.hidden = true;
        } finally {
            loadMore.disabled = false;
        }
    }

    function emptyState() {
        const q = esc(state.q);
        const shareLink = '#perfil?secao=habilidades';  // pede login se necessário
        if (state.q && state.tipo === 'teach') {
            return `<div class="empty-state">
                <h3>Ninguém ensina &ldquo;${q}&rdquo; ainda</h3>
                <p>Adicione &ldquo;${q}&rdquo; na sua lista de <strong>Quero aprender</strong>: assim quem souber pode te encontrar.</p>
                <a href="${shareLink}" class="btn btn-gradient">Atualizar minhas habilidades</a>
            </div>`;
        }
        if (state.q) {
            return `<div class="empty-state"><h3>Nenhum resultado para &ldquo;${q}&rdquo;</h3>
                <p>Tente outro termo ou mude o filtro acima.</p></div>`;
        }
        return `<div class="empty-state"><h3>Ainda não há pessoas por aqui</h3>
            <p>Seja uma das primeiras: cadastre o que você sabe e o que quer aprender.</p>
            <a href="${shareLink}" class="btn btn-gradient">Cadastrar minhas habilidades</a></div>`;
    }
}

async function loadPopular() {
    const box = document.querySelector('[data-popular]');
    try {
        const data = await api.get('skills.php');
        box.hidden = data.skills.length === 0;
        document.querySelector('[data-popular-list]').innerHTML = data.skills
            .map(skill => `<button type="button" class="chip chip--button" data-skill="${esc(skill)}">${esc(skill)}</button>`)
            .join('');
    } catch (e) {
        box.hidden = true;
    }
}

function skeletons(count) {
    return Array.from({ length: count }, () => '<div class="user-card user-card--skeleton" aria-hidden="true"></div>').join('');
}
