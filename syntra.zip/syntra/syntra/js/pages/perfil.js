/* ==========================================================
   Página Meu perfil: dados, habilidades, senha
   ========================================================== */

import { api, setCsrf } from '../api.js';
import { route } from '../router.js';
import { getUser, setUser, onUserChange } from '../session.js';
import { esc, formData, clearErrors, showErrors, withLoading, toast } from '../ui.js';

const MAX_SKILLS = 15;
const lists = { teach: [], learn: [] };
let dirty = false;

export function initPerfil() {
    const profileForm = document.querySelector('[data-profile-form]');
    const skillsForm = document.querySelector('[data-skills-form]');
    const passwordForm = document.querySelector('[data-password-form]');

    /* ---------- Editores de habilidades (chips) ---------- */
    skillsForm.querySelectorAll('.skill-editor').forEach(editor => {
        const kind = editor.dataset.kind;
        const input = editor.querySelector('input');
        const chips = editor.querySelector('[data-chips]');

        const add = () => {
            const names = input.value.split(/[,;]/).map(s => s.trim().replace(/\s+/g, ' ')).filter(Boolean);
            for (const name of names) {
                if (name.length < 2 || name.length > 40) {
                    toast('Cada habilidade deve ter entre 2 e 40 caracteres.', 'error');
                    continue;
                }
                if (lists[kind].some(s => s.toLowerCase() === name.toLowerCase())) continue;
                if (lists[kind].length >= MAX_SKILLS) {
                    toast(`Máximo de ${MAX_SKILLS} habilidades em cada lista.`, 'error');
                    break;
                }
                lists[kind].push(name);
                setDirty(true);
            }
            input.value = '';
            renderChips(kind);
        };

        input.addEventListener('keydown', event => {
            if (event.key === 'Enter' || event.key === ',') {
                event.preventDefault();
                add();
            } else if (event.key === 'Backspace' && !input.value && lists[kind].length) {
                lists[kind].pop();
                setDirty(true);
                renderChips(kind);
            }
        });
        // Escolher uma sugestão da lista também adiciona
        input.addEventListener('change', () => { if (input.value.trim()) add(); });
        input.addEventListener('blur', () => { if (input.value.trim()) add(); });

        chips.addEventListener('click', event => {
            const remove = event.target.closest('[data-remove]');
            if (!remove) return;
            lists[kind].splice(Number(remove.dataset.remove), 1);
            setDirty(true);
            renderChips(kind);
            input.focus();
        });

        editor.querySelector('.chip-input').addEventListener('click', event => {
            if (event.target.classList.contains('chip-input')) input.focus();
        });
    });

    skillsForm.addEventListener('submit', async event => {
        event.preventDefault();
        // Adiciona o que ainda estiver digitado
        skillsForm.querySelectorAll('.skill-editor input').forEach(input => {
            if (input.value.trim()) input.dispatchEvent(new Event('change'));
        });
        await withLoading(skillsForm.querySelector('[type=submit]'), async () => {
            try {
                const result = await api.post('profile.php?action=skills', lists);
                setDirty(false);
                setUser(result.user);
                toast(result.message);
            } catch (error) {
                toast(error.message, 'error');
            }
        });
    });

    /* ---------- Dados pessoais ---------- */
    profileForm.addEventListener('submit', async event => {
        event.preventDefault();
        clearErrors(profileForm);
        const data = formData(profileForm);   // lê antes de travar o formulário
        await withLoading(profileForm.querySelector('[type=submit]'), async () => {
            try {
                const result = await api.post('profile.php?action=update', data);
                setUser(result.user);
                toast(result.message);
            } catch (error) {
                showErrors(profileForm, error);
            }
        });
    });

    /* ---------- Senha ---------- */
    passwordForm.addEventListener('submit', async event => {
        event.preventDefault();
        clearErrors(passwordForm);
        const data = formData(passwordForm);   // lê antes de travar o formulário
        await withLoading(passwordForm.querySelector('[type=submit]'), async () => {
            try {
                const result = await api.post('profile.php?action=password', data);
                setCsrf(result.csrf);
                passwordForm.reset();
                toast(result.message);
            } catch (error) {
                showErrors(passwordForm, error);
            }
        });
    });

    /* ---------- Ao abrir a página ---------- */
    route('perfil', ({ query }) => {
        fill(getUser());
        if (query.get('secao') === 'habilidades') {
            const section = document.getElementById('secao-habilidades');
            setTimeout(() => {
                section.scrollIntoView({ behavior: 'smooth', block: 'start' });
                section.classList.add('is-highlighted');
                setTimeout(() => section.classList.remove('is-highlighted'), 1600);
                const teachInput = section.querySelector('#skill-teach-input');
                if (!lists.teach.length) teachInput.focus({ preventScroll: true });
            }, 80);
        }
    });

    // Mantém o resumo e checklist atualizados
    onUserChange(user => {
        if (user && document.getElementById('perfil').classList.contains('active-page')) {
            renderSummary(user);
        }
    });

    // Aviso ao sair da página com habilidades não salvas
    window.addEventListener('beforeunload', event => {
        if (dirty) {
            event.preventDefault();
            event.returnValue = '';
        }
    });
}

function fill(user) {
    if (!user) return;
    const profileForm = document.querySelector('[data-profile-form]');
    profileForm.name.value = user.name || '';
    profileForm.course.value = user.course || '';
    profileForm.city.value = user.city || '';
    profileForm.bio.value = user.bio || '';

    if (!dirty) {
        lists.teach = [...user.teach];
        lists.learn = [...user.learn];
    }
    renderChips('teach');
    renderChips('learn');
    renderSummary(user);
}

function renderChips(kind) {
    const editor = document.querySelector(`.skill-editor[data-kind="${kind}"]`);
    editor.querySelector('[data-chips]').innerHTML = lists[kind].map((skill, index) => `
        <span class="chip chip--${kind}">
            ${esc(skill)}
            <button type="button" data-remove="${index}" aria-label="Remover ${esc(skill)}">&times;</button>
        </span>`).join('');
}

function renderSummary(user) {
    document.querySelector('[data-my-public-link]').href = `#usuario/${user.id}`;

    const items = [
        [user.teach.length > 0, 'O que você pode ensinar'],
        [user.learn.length > 0, 'O que você quer aprender'],
        [Boolean(user.course), 'Curso / área'],
        [Boolean(user.bio), 'Sobre mim'],
    ];
    const done = items.filter(([ok]) => ok).length;
    const percent = Math.round((done / items.length) * 100);

    document.querySelector('[data-profile-checklist]').innerHTML = `
        <div class="progress" role="progressbar" aria-valuenow="${percent}" aria-valuemin="0" aria-valuemax="100">
            <span style="width:${percent}%"></span>
        </div>
        <small>Perfil ${percent}% completo</small>
        <ul>${items.map(([ok, label]) => `<li class="${ok ? 'is-done' : ''}">${esc(label)}</li>`).join('')}</ul>`;
}

function setDirty(value) {
    dirty = value;
    const button = document.querySelector('[data-skills-form] [type=submit]');
    button.classList.toggle('has-changes', value);
    button.title = value ? 'Há alterações não salvas' : '';
}
