<?php
/**
 * Roteador para o servidor embutido do PHP (apenas para testes locais):
 *     php -S localhost:8000 router.php
 *
 * O servidor embutido ignora os arquivos .htaccess, então este arquivo
 * bloqueia as pastas internas (banco de dados, configuração, etc.).
 * No Apache/XAMPP quem faz esse bloqueio são os .htaccess de cada pasta.
 */

$path = rawurldecode(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH));

if (preg_match('#^/(config|includes|data|database)(/|$)#i', $path) || preg_match('#/\.#', $path)) {
    http_response_code(403);
    exit('Acesso negado.');
}

if ($path === '/') {
    readfile(__DIR__ . '/index.html');
    return true;
}

return false; // deixa o servidor entregar o arquivo normalmente
