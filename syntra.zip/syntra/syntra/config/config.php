<?php
/**
 * SYNTRA - Configurações
 *
 * Copie este arquivo para "config.php" (na mesma pasta) e preencha.
 * O config.php guarda senhas: NÃO publique no GitHub (já está no .gitignore).
 */

return [

    /* ------------------------------------------------------------
     * Banco de dados
     * ------------------------------------------------------------
     * 'sqlite' -> funciona sem instalar nada: o arquivo do banco é
     *             criado sozinho em data/syntra.sqlite
     * 'mysql'  -> use no XAMPP/hospedagem. Crie o banco vazio no
     *             phpMyAdmin (ex.: "syntra"); as tabelas são criadas
     *             automaticamente no primeiro acesso.
     */
    'db' => [
        'driver'   => 'sqlite',

        'sqlite_path' => __DIR__ . '/../data/syntra.sqlite',

        'host'     => '127.0.0.1',
        'port'     => 3306,
        'database' => 'syntra',
        'username' => 'root',
        'password' => '',
    ],

    /* ------------------------------------------------------------
     * E-mail (formulário de contato, "esqueci a senha" e avisos
     * de novas conexões)
     * ------------------------------------------------------------
     * Para Gmail use uma "Senha de app" (exige verificação em 2
     * etapas: Conta Google > Segurança > Senhas de app).
     * Deixe 'senha' vazio para usar a função mail() do servidor.
     */
    'email' => [
        'destino_contato' => 'mesm.souzamariano@gmail.com',   // recebe o formulário de contato
        'smtp' => [
            'host'       => 'smtp.gmail.com',
            'usuario'    => 'mesm.souzamariano@gmail.com',
            'senha'      => 'cloi hznz birn ifvq', //cloi hznz birn ifvq
            'porta'      => 587,
            'encryption' => 'tls',
        ],
    ],

    /* ------------------------------------------------------------
     * Site
     * ------------------------------------------------------------ */
    'site' => [
        'nome'     => 'SYNTRA',
        // Endereço público do site, usado nos links enviados por e-mail.
        // Deixe vazio para detectar automaticamente.
        // Ex.: 'https://www.sintra.com.br' ou 'http://localhost/syntra'
        'url'      => '',
        'timezone' => 'America/Sao_Paulo',

        // SOMENTE para testes no seu computador: se o e-mail não estiver
        // configurado, o link de "esqueci a senha" aparece na tela.
        // NUNCA deixe true em um site publicado.
        'modo_desenvolvimento' => false,
    ],
];
