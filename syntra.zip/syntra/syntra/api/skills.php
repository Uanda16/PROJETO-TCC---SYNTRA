<?php
/**
 * API de habilidades (sugestões para os campos e as mais populares)
 *
 * GET api/skills.php?q=pyt     -> sugestões que começam/contêm o texto
 * GET api/skills.php           -> habilidades mais cadastradas
 */

require __DIR__ . '/../includes/bootstrap.php';
require_method('GET');

$q = normalize_text(mb_substr((string) ($_GET['q'] ?? ''), 0, 40));

if ($q !== '') {
    $stmt = db()->prepare(
        "SELECT s.name, COUNT(us.user_id) AS total
           FROM skills s
           LEFT JOIN user_skills us ON us.skill_id = s.id
          WHERE s.slug LIKE ? ESCAPE '!'
          GROUP BY s.id, s.name, s.slug
          ORDER BY CASE WHEN s.slug LIKE ? ESCAPE '!' THEN 0 ELSE 1 END, total DESC, s.name
          LIMIT 8"
    );
    $stmt->execute(['%' . like_escape($q) . '%', like_escape($q) . '%']);
} else {
    $stmt = db()->query(
        "SELECT s.name, COUNT(us.user_id) AS total
           FROM skills s
           JOIN user_skills us ON us.skill_id = s.id AND us.kind = 'teach'
          GROUP BY s.id, s.name
          ORDER BY total DESC, s.name
          LIMIT 12"
    );
}

json_response(['skills' => array_column($stmt->fetchAll(), 'name')]);
