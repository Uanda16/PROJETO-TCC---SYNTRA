<?php
/**
 * API de perfil público
 *
 * GET api/users.php?id=12
 * O e-mail só aparece para quem tem conexão aceita com a pessoa.
 */

require __DIR__ . '/../includes/bootstrap.php';
require_method('GET');

$id = (int) ($_GET['id'] ?? 0);
$stmt = db()->prepare('SELECT * FROM users WHERE id = ?');
$stmt->execute([$id]);
$user = $stmt->fetch();

if (!$user) {
    json_error('Usuário não encontrado.', 404);
}

$me = current_user_id();
$connection = null;
$showEmail = false;

if ($me) {
    $conn = connection_between($me, $id);
    $connection = connection_state($conn, $me);
    $showEmail = $me === $id || ($conn && $conn['status'] === 'accepted');
}

$skills = skills_for_users([$id])[$id];

json_response([
    'user' => public_user($user, $showEmail) + [
        'teach'      => $skills['teach'],
        'learn'      => $skills['learn'],
        'connection' => $connection,
        'is_me'      => $me === $id,
    ],
]);
