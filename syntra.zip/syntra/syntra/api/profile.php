<?php
/**
 * API do perfil do usuário logado
 *
 * GET  api/profile.php                    -> dados do perfil
 * POST api/profile.php?action=update      -> nome, curso, cidade, bio
 * POST api/profile.php?action=skills      -> listas completas { teach: [...], learn: [...] }
 * POST api/profile.php?action=password    -> trocar senha
 * POST api/profile.php?action=delete      -> excluir conta
 */

require __DIR__ . '/../includes/bootstrap.php';

const MAX_SKILLS_PER_KIND = 15;

$user = require_login();
$userId = (int) $user['id'];

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    json_response(['user' => me_payload($user)]);
}

switch (action()) {

    /* ------------------------------------------------------------ */
    case 'update':
        $name   = input_str('name', 80);
        $course = input_str('course', 100);
        $city   = input_str('city', 80);
        $bio    = trim(mb_substr((string) (input()['bio'] ?? ''), 0, 600));

        if (!valid_name($name)) {
            json_error('Confira os campos destacados.', 422, ['name' => 'Informe seu nome completo.']);
        }

        db()->prepare('UPDATE users SET name = ?, name_search = ?, course = ?, city = ?, bio = ?, updated_at = ? WHERE id = ?')
            ->execute([$name, normalize_text($name), $course ?: null, $city ?: null, $bio ?: null, now(), $userId]);

        json_response(['user' => me_payload(reload_user($userId)), 'message' => 'Perfil atualizado!']);

    /* ------------------------------------------------------------ */
    case 'skills':
        $lists = [];
        foreach (['teach', 'learn'] as $kind) {
            $raw = input()[$kind] ?? [];
            if (!is_array($raw)) {
                $raw = [];
            }
            $clean = [];
            foreach ($raw as $name) {
                if (!is_string($name)) {
                    continue;
                }
                $name = trim(preg_replace('/\s+/u', ' ', $name));
                $slug = normalize_text($name);
                if (mb_strlen($name) < 2 || mb_strlen($name) > 40) {
                    json_error("A habilidade \"$name\" precisa ter entre 2 e 40 caracteres.", 422);
                }
                $clean[$slug] = $name;   // remove repetidas
            }
            if (count($clean) > MAX_SKILLS_PER_KIND) {
                json_error('Você pode cadastrar no máximo ' . MAX_SKILLS_PER_KIND . ' habilidades em cada lista.', 422);
            }
            $lists[$kind] = $clean;
        }

        $pdo = db();
        $pdo->beginTransaction();
        try {
            $pdo->prepare('DELETE FROM user_skills WHERE user_id = ?')->execute([$userId]);
            $insert = $pdo->prepare('INSERT INTO user_skills (user_id, skill_id, kind) VALUES (?, ?, ?)');
            foreach ($lists as $kind => $skills) {
                foreach ($skills as $slug => $name) {
                    $insert->execute([$userId, skill_id($slug, $name), $kind]);
                }
            }
            $pdo->commit();
        } catch (Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }

        json_response(['user' => me_payload(reload_user($userId)), 'message' => 'Habilidades salvas!']);

    /* ------------------------------------------------------------ */
    case 'password':
        $current  = (string) (input()['current_password'] ?? '');
        $password = (string) (input()['password'] ?? '');
        $confirm  = (string) (input()['password_confirm'] ?? '');

        if (!password_verify($current, $user['password_hash'])) {
            json_error('Senha atual incorreta.', 422, ['current_password' => 'Senha atual incorreta.']);
        }
        if ($problem = password_problem($password)) {
            json_error($problem, 422, ['password' => $problem]);
        }
        if ($password !== $confirm) {
            json_error('As senhas não conferem.', 422, ['password_confirm' => 'As senhas não conferem.']);
        }

        db()->prepare('UPDATE users SET password_hash = ?, updated_at = ? WHERE id = ?')
            ->execute([password_hash($password, PASSWORD_DEFAULT), now(), $userId]);
        login_user($userId); // nova sessão
        json_response(['csrf' => csrf_token(), 'message' => 'Senha alterada com sucesso!']);

    /* ------------------------------------------------------------ */
    case 'delete':
        $password = (string) (input()['password'] ?? '');
        if (!password_verify($password, $user['password_hash'])) {
            json_error('Senha incorreta.', 422, ['password' => 'Senha incorreta.']);
        }
        db()->prepare('DELETE FROM users WHERE id = ?')->execute([$userId]);
        logout_user();
        json_response(['csrf' => csrf_token(), 'message' => 'Sua conta foi excluída.']);

    default:
        json_error('Ação inválida.', 404);
}

/* ---------------------------------------------------------------- */

function reload_user(int $id): array
{
    $stmt = db()->prepare('SELECT * FROM users WHERE id = ?');
    $stmt->execute([$id]);
    return $stmt->fetch();
}

/** Busca o id da habilidade ou cria uma nova. */
function skill_id(string $slug, string $name): int
{
    $stmt = db()->prepare('SELECT id FROM skills WHERE slug = ?');
    $stmt->execute([$slug]);
    if ($id = $stmt->fetchColumn()) {
        return (int) $id;
    }
    // Primeira letra maiúscula para padronizar a exibição
    $display = mb_strtoupper(mb_substr($name, 0, 1)) . mb_substr($name, 1);
    db()->prepare('INSERT INTO skills (name, slug, created_at) VALUES (?, ?, ?)')->execute([$display, $slug, now()]);
    return (int) db()->lastInsertId();
}
