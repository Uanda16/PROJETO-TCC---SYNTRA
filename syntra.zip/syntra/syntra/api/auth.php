<?php
/**
 * API de autenticação
 *
 * GET  api/auth.php?action=me           -> usuário logado (ou null) + token CSRF
 * POST api/auth.php?action=register     -> cadastro
 * POST api/auth.php?action=login        -> entrar
 * POST api/auth.php?action=logout       -> sair
 * POST api/auth.php?action=forgot       -> envia link para redefinir a senha
 * GET  api/auth.php?action=reset_check  -> verifica se o link ainda vale
 * POST api/auth.php?action=reset        -> grava a nova senha
 */

require __DIR__ . '/../includes/bootstrap.php';

switch (action()) {

    /* ------------------------------------------------------------ */
    case 'me':
        require_method('GET');
        json_response([
            'csrf' => csrf_token(),
            'user' => ($user = current_user()) ? me_payload($user) : null,
        ]);

    /* ------------------------------------------------------------ */
    case 'register':
        require_method('POST');

        $name     = input_str('name', 80);
        $email    = mb_strtolower(input_str('email', 190));
        $password = (string) (input()['password'] ?? '');
        $confirm  = (string) (input()['password_confirm'] ?? '');
        $course   = input_str('course', 100);
        $terms    = !empty(input()['terms']);

        $errors = [];
        if (!valid_name($name)) {
            $errors['name'] = 'Informe seu nome completo (apenas letras).';
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors['email'] = 'Informe um e-mail válido.';
        }
        if ($problem = password_problem($password)) {
            $errors['password'] = $problem;
        } elseif ($password !== $confirm) {
            $errors['password_confirm'] = 'As senhas não conferem.';
        }
        if (!$terms) {
            $errors['terms'] = 'É preciso aceitar os termos de uso.';
        }
        if (empty($errors['email'])) {
            $stmt = db()->prepare('SELECT 1 FROM users WHERE email = ?');
            $stmt->execute([$email]);
            if ($stmt->fetchColumn()) {
                $errors['email'] = 'Este e-mail já está cadastrado. Tente entrar.';
            }
        }
        if ($errors) {
            json_error('Confira os campos destacados.', 422, $errors);
        }

        $now = now();
        db()->prepare(
            'INSERT INTO users (name, name_search, email, password_hash, course, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, ?)'
        )->execute([$name, normalize_text($name), $email, password_hash($password, PASSWORD_DEFAULT), $course ?: null, $now, $now]);

        $userId = (int) db()->lastInsertId();
        login_user($userId);

        $stmt = db()->prepare('SELECT * FROM users WHERE id = ?');
        $stmt->execute([$userId]);
        json_response(['csrf' => csrf_token(), 'user' => me_payload($stmt->fetch())], 201);

    /* ------------------------------------------------------------ */
    case 'login':
        require_method('POST');

        $email    = mb_strtolower(input_str('email', 190));
        $password = (string) (input()['password'] ?? '');

        if ($email === '' || $password === '') {
            json_error('Informe e-mail e senha.', 422);
        }
        if (login_is_locked($email)) {
            json_error('Muitas tentativas sem sucesso. Aguarde ' . LOGIN_LOCK_MINUTES . ' minutos e tente de novo, ou redefina sua senha.', 429);
        }

        $stmt = db()->prepare('SELECT * FROM users WHERE email = ?');
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if (!$user || !password_verify($password, $user['password_hash'])) {
            login_register_failure($email);
            json_error('E-mail ou senha incorretos.', 401);
        }

        // Atualiza o hash se o PHP passou a usar um algoritmo mais forte
        if (password_needs_rehash($user['password_hash'], PASSWORD_DEFAULT)) {
            db()->prepare('UPDATE users SET password_hash = ? WHERE id = ?')
                ->execute([password_hash($password, PASSWORD_DEFAULT), $user['id']]);
        }

        login_clear_failures($email);
        login_user((int) $user['id']);
        json_response(['csrf' => csrf_token(), 'user' => me_payload($user)]);

    /* ------------------------------------------------------------ */
    case 'logout':
        require_method('POST');
        logout_user();
        json_response(['csrf' => csrf_token(), 'user' => null]);

    /* ------------------------------------------------------------ */
    case 'forgot':
        require_method('POST');
        require_once __DIR__ . '/../includes/mailer.php';

        $email = mb_strtolower(input_str('email', 190));
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            json_error('Informe um e-mail válido.', 422, ['email' => 'Informe um e-mail válido.']);
        }

        // Limite simples: 1 pedido por minuto por sessão
        if (!empty($_SESSION['last_forgot']) && time() - $_SESSION['last_forgot'] < 60) {
            json_error('Aguarde um minuto antes de pedir outro link.', 429);
        }
        $_SESSION['last_forgot'] = time();

        // A resposta é a mesma exista ou não a conta (não revela e-mails cadastrados)
        $generic = 'Se este e-mail estiver cadastrado, você vai receber um link para criar uma nova senha. Confira também a caixa de spam.';

        $stmt = db()->prepare('SELECT id, name FROM users WHERE email = ?');
        $stmt->execute([$email]);
        $user = $stmt->fetch();
        if (!$user) {
            json_response(['message' => $generic]);
        }

        $token = bin2hex(random_bytes(32));
        db()->prepare('DELETE FROM password_resets WHERE user_id = ?')->execute([$user['id']]);
        db()->prepare('INSERT INTO password_resets (user_id, token_hash, expires_at, created_at) VALUES (?, ?, ?, ?)')
            ->execute([$user['id'], hash('sha256', $token), date('Y-m-d H:i:s', time() + 3600), now()]);

        $link = site_url() . '/index.html#redefinir/' . $token;

        if (!mail_configured() && config('site.modo_desenvolvimento')) {
            // Apenas para testes locais (ver config.php)
            json_response(['message' => 'Modo de desenvolvimento: e-mail não configurado, use o link abaixo.', 'dev_link' => $link]);
        }

        $html = mail_template(
            'Redefinição de senha',
            '<p>Olá, ' . htmlspecialchars($user['name']) . '!</p>'
            . '<p>Recebemos um pedido para criar uma nova senha para sua conta. O link vale por 1 hora.</p>',
            'Criar nova senha',
            $link
        ) . '<p style="font-family:Arial;font-size:12px;color:#6b7190">Se não foi você, ignore este e-mail: sua senha continua a mesma.</p>';

        $sent = send_mail($email, 'SYNTRA - Redefinição de senha', $html);
        if ($sent !== true) {
            json_error('Não foi possível enviar o e-mail agora. Tente mais tarde ou fale conosco pela página Contato.', 503);
        }
        json_response(['message' => $generic]);

    /* ------------------------------------------------------------ */
    case 'reset_check':
        require_method('GET');
        json_response(['valid' => (bool) find_reset((string) ($_GET['token'] ?? ''))]);

    /* ------------------------------------------------------------ */
    case 'reset':
        require_method('POST');

        $reset    = find_reset(input_str('token', 64));
        $password = (string) (input()['password'] ?? '');
        $confirm  = (string) (input()['password_confirm'] ?? '');

        if (!$reset) {
            json_error('Este link é inválido ou já expirou. Peça um novo em "Esqueci minha senha".', 410);
        }
        if ($problem = password_problem($password)) {
            json_error($problem, 422, ['password' => $problem]);
        }
        if ($password !== $confirm) {
            json_error('As senhas não conferem.', 422, ['password_confirm' => 'As senhas não conferem.']);
        }

        db()->prepare('UPDATE users SET password_hash = ?, updated_at = ? WHERE id = ?')
            ->execute([password_hash($password, PASSWORD_DEFAULT), now(), $reset['user_id']]);
        db()->prepare('UPDATE password_resets SET used_at = ? WHERE id = ?')->execute([now(), $reset['id']]);

        $stmt = db()->prepare('SELECT * FROM users WHERE id = ?');
        $stmt->execute([$reset['user_id']]);
        $user = $stmt->fetch();
        login_clear_failures($user['email']);
        login_user((int) $user['id']);
        json_response(['csrf' => csrf_token(), 'user' => me_payload($user)]);

    default:
        json_error('Ação inválida.', 404);
}

/* ---------------------------------------------------------------- */

function find_reset(string $token): ?array
{
    if (!preg_match('/^[a-f0-9]{64}$/', $token)) {
        return null;
    }
    $stmt = db()->prepare('SELECT * FROM password_resets WHERE token_hash = ? AND used_at IS NULL AND expires_at > ?');
    $stmt->execute([hash('sha256', $token), now()]);
    return $stmt->fetch() ?: null;
}
