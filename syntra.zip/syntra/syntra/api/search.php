<?php
/**
 * API de busca de pessoas
 *
 * GET api/search.php?q=python&type=teach&page=1
 *   q    -> habilidade ou nome (opcional)
 *   type -> teach (quem ensina) | learn (quem quer aprender) | all
 */

require __DIR__ . '/../includes/bootstrap.php';
require_method('GET');

const PER_PAGE = 12;

$q    = normalize_text(mb_substr((string) ($_GET['q'] ?? ''), 0, 60));
$type = in_array($_GET['type'] ?? '', ['teach', 'learn', 'all'], true) ? $_GET['type'] : 'teach';
$page = max(1, (int) ($_GET['page'] ?? 1));
$me   = current_user_id() ?? 0;

/*
 * Para cada usuário calculamos:
 *  - matches:    quantas habilidades dele combinam com a busca (no tipo escolhido)
 *  - skill_count: quantas habilidades ele tem no tipo escolhido
 *  - name_match: se o nome combina com a busca
 */
$kindSql = $type === 'all' ? '' : ' AND us.kind = ?';
$kindParams = $type === 'all' ? [] : [$type];
$like = '%' . like_escape($q) . '%';

$inner = "SELECT u.*,
                 (SELECT COUNT(*) FROM user_skills us JOIN skills s ON s.id = us.skill_id
                   WHERE us.user_id = u.id AND s.slug LIKE ? ESCAPE '!' $kindSql) AS matches,
                 (SELECT COUNT(*) FROM user_skills us
                   WHERE us.user_id = u.id $kindSql) AS skill_count,
                 CASE WHEN u.name_search LIKE ? ESCAPE '!' THEN 1 ELSE 0 END AS name_match
            FROM users u
           WHERE u.id <> ?";
$params = array_merge([$like], $kindParams, $kindParams, [$like, $me]);

if ($q !== '') {
    $where = 'WHERE t.matches > 0 OR t.name_match = 1';
} else {
    // Sem texto: lista quem tem pelo menos uma habilidade do tipo escolhido
    $where = 'WHERE t.skill_count > 0';
}

$countStmt = db()->prepare("SELECT COUNT(*) FROM ($inner) t $where");
$countStmt->execute($params);
$total = (int) $countStmt->fetchColumn();

$offset = ($page - 1) * PER_PAGE;
$stmt = db()->prepare(
    "SELECT * FROM ($inner) t $where
      ORDER BY t.matches DESC, t.name_match DESC, t.skill_count DESC, t.created_at DESC
      LIMIT " . PER_PAGE . " OFFSET " . (int) $offset
);
$stmt->execute($params);
$rows = $stmt->fetchAll();

$skills = skills_for_users(array_column($rows, 'id'));
$results = [];
foreach ($rows as $row) {
    $id = (int) $row['id'];
    $results[] = public_user($row) + [
        'teach'      => $skills[$id]['teach'],
        'learn'      => $skills[$id]['learn'],
        'connection' => $me ? connection_state(connection_between($me, $id), $me) : null,
    ];
}

json_response([
    'results' => $results,
    'total'   => $total,
    'page'    => $page,
    'pages'   => max(1, (int) ceil($total / PER_PAGE)),
]);
