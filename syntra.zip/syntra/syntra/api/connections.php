<?php
/**
 * API de conexões entre usuários
 *
 * GET  api/connections.php                    -> recebidas, enviadas e conexões ativas
 * POST api/connections.php?action=request     -> { user_id, skill, message }
 * POST api/connections.php?action=respond     -> { id, accept: true|false }
 * POST api/connections.php?action=cancel      -> { id }  cancela uma solicitação enviada
 * POST api/connections.php?action=remove      -> { id }  desfaz uma conexão
 */

require __DIR__ . '/../includes/bootstrap.php';
require_once __DIR__ . '/../includes/mailer.php';

$user = require_login();
$me = (int) $user['id'];

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    json_response(list_connections($me));
}

switch (action()) {

    /* ------------------------------------------------------------ */
    case 'request':
        $otherId = (int) (input()['user_id'] ?? 0);
        $skill   = input_str('skill', 40);
        $message = trim(mb_substr((string) (input()['message'] ?? ''), 0, 500));

        if ($otherId === $me) {
            json_error('Você não pode se conectar com você mesmo.', 422);
        }
        $stmt = db()->prepare('SELECT * FROM users WHERE id = ?');
        $stmt->execute([$otherId]);
        $other = $stmt->fetch();
        if (!$other) {
            json_error('Usuário não encontrado.', 404);
        }

        if ($existing = connection_between($me, $otherId)) {
            $state = connection_state($existing, $me);
            if ($existing['status'] === 'accepted') {
                json_error('Vocês já estão conectados.', 409);
            }
            if ($state['direction'] === 'received' && $existing['status'] === 'pending') {
                json_error('Esta pessoa já te enviou uma solicitação. Veja em "Conexões".', 409);
            }
            if ($state['direction'] === 'sent' && $existing['status'] === 'pending') {
                json_error('Você já enviou uma solicitação para esta pessoa.', 409);
            }
            if ($state['direction'] === 'sent' && $existing['status'] === 'declined') {
                json_error('Esta pessoa não aceitou sua solicitação anterior.', 409);
            }
            // Eu tinha recusado a pessoa e agora quero me conectar: remove o registro antigo
            db()->prepare('DELETE FROM connections WHERE id = ?')->execute([$existing['id']]);
        }

        $skillId = null;
        if ($skill !== '') {
            $stmt = db()->prepare('SELECT id FROM skills WHERE slug = ?');
            $stmt->execute([normalize_text($skill)]);
            $skillId = $stmt->fetchColumn() ?: null;
        }

        db()->prepare(
            "INSERT INTO connections (requester_id, addressee_id, skill_id, message, status, created_at, updated_at)
             VALUES (?, ?, ?, ?, 'pending', ?, ?)"
        )->execute([$me, $otherId, $skillId, $message ?: null, now(), now()]);

        notify($other['email'], 'SYNTRA - Nova solicitação de conexão',
            mail_template(
                'Você recebeu uma solicitação de conexão',
                '<p><strong>' . htmlspecialchars($user['name']) . '</strong> quer se conectar com você'
                . ($skill !== '' ? ' sobre <strong>' . htmlspecialchars($skill) . '</strong>' : '') . '.</p>'
                . ($message !== '' ? '<blockquote style="border-left:3px solid #8b5cf6;margin:0;padding:6px 14px;color:#3f4566">'
                    . nl2br(htmlspecialchars($message)) . '</blockquote>' : ''),
                'Ver solicitação',
                site_url() . '/index.html#conexoes'
            )
        );

        json_response(['message' => 'Solicitação enviada para ' . $other['name'] . '!'], 201);

    /* ------------------------------------------------------------ */
    case 'respond':
        $conn = find_connection((int) (input()['id'] ?? 0));
        if ((int) $conn['addressee_id'] !== $me || $conn['status'] !== 'pending') {
            json_error('Solicitação não encontrada.', 404);
        }
        $accept = !empty(input()['accept']);
        db()->prepare('UPDATE connections SET status = ?, updated_at = ? WHERE id = ?')
            ->execute([$accept ? 'accepted' : 'declined', now(), $conn['id']]);

        if ($accept) {
            $stmt = db()->prepare('SELECT email FROM users WHERE id = ?');
            $stmt->execute([$conn['requester_id']]);
            notify((string) $stmt->fetchColumn(), 'SYNTRA - Solicitação aceita!',
                mail_template(
                    'Sua solicitação foi aceita',
                    '<p><strong>' . htmlspecialchars($user['name']) . '</strong> aceitou se conectar com você. '
                    . 'Agora vocês podem ver o e-mail um do outro e combinar a troca de conhecimento.</p>',
                    'Ver minhas conexões',
                    site_url() . '/index.html#conexoes'
                )
            );
        }
        json_response(['message' => $accept ? 'Conexão aceita!' : 'Solicitação recusada.'] + list_connections($me));

    /* ------------------------------------------------------------ */
    case 'cancel':
        $conn = find_connection((int) (input()['id'] ?? 0));
        if ((int) $conn['requester_id'] !== $me || $conn['status'] !== 'pending') {
            json_error('Solicitação não encontrada.', 404);
        }
        db()->prepare('DELETE FROM connections WHERE id = ?')->execute([$conn['id']]);
        json_response(['message' => 'Solicitação cancelada.'] + list_connections($me));

    /* ------------------------------------------------------------ */
    case 'remove':
        $conn = find_connection((int) (input()['id'] ?? 0));
        $isPart = in_array($me, [(int) $conn['requester_id'], (int) $conn['addressee_id']], true);
        if (!$isPart || $conn['status'] !== 'accepted') {
            json_error('Conexão não encontrada.', 404);
        }
        db()->prepare('DELETE FROM connections WHERE id = ?')->execute([$conn['id']]);
        json_response(['message' => 'Conexão desfeita.'] + list_connections($me));

    default:
        json_error('Ação inválida.', 404);
}

/* ---------------------------------------------------------------- */

function find_connection(int $id): array
{
    $stmt = db()->prepare('SELECT * FROM connections WHERE id = ?');
    $stmt->execute([$id]);
    $conn = $stmt->fetch();
    if (!$conn) {
        json_error('Solicitação não encontrada.', 404);
    }
    return $conn;
}

function list_connections(int $me): array
{
    $stmt = db()->prepare(
        "SELECT c.*, s.name AS skill_name,
                u.id AS u_id, u.name AS u_name, u.email AS u_email, u.course AS u_course,
                u.city AS u_city, u.bio AS u_bio, u.created_at AS u_created_at
           FROM connections c
           JOIN users u ON u.id = CASE WHEN c.requester_id = ? THEN c.addressee_id ELSE c.requester_id END
           LEFT JOIN skills s ON s.id = c.skill_id
          WHERE c.requester_id = ? OR c.addressee_id = ?
          ORDER BY c.updated_at DESC"
    );
    $stmt->execute([$me, $me, $me]);
    $rows = $stmt->fetchAll();

    $skills = skills_for_users(array_unique(array_column($rows, 'u_id')));
    $out = ['received' => [], 'sent' => [], 'accepted' => []];

    foreach ($rows as $row) {
        $sent = (int) $row['requester_id'] === $me;
        $accepted = $row['status'] === 'accepted';
        $otherId = (int) $row['u_id'];

        $item = [
            'id'      => (int) $row['id'],
            'status'  => $row['status'],
            'skill'   => $row['skill_name'],
            'message' => $row['message'],
            'date'    => $row['updated_at'],
            'user'    => public_user([
                'id' => $otherId, 'name' => $row['u_name'], 'email' => $row['u_email'],
                'course' => $row['u_course'], 'city' => $row['u_city'], 'bio' => $row['u_bio'],
                'created_at' => $row['u_created_at'],
            ], $accepted) + $skills[$otherId],
        ];

        if ($accepted) {
            $out['accepted'][] = $item;
        } elseif ($sent) {
            $out['sent'][] = $item;                       // pendentes e recusadas
        } elseif ($row['status'] === 'pending') {
            $out['received'][] = $item;                   // recusadas por mim não aparecem
        }
    }
    return $out;
}

/** Aviso por e-mail (só se o SMTP estiver configurado; falhas não interrompem nada). */
function notify(string $to, string $subject, string $html): void
{
    if ($to !== '' && mail_configured()) {
        send_mail($to, $subject, $html);
    }
}
