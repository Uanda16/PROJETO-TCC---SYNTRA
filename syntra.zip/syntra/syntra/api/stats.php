<?php
/**
 * Números gerais da plataforma (página "Sobre")
 * GET api/stats.php
 */

require __DIR__ . '/../includes/bootstrap.php';
require_method('GET');

json_response([
    'users'       => (int) db()->query('SELECT COUNT(*) FROM users')->fetchColumn(),
    'skills'      => (int) db()->query('SELECT COUNT(DISTINCT skill_id) FROM user_skills')->fetchColumn(),
    'connections' => (int) db()->query("SELECT COUNT(*) FROM connections WHERE status = 'accepted'")->fetchColumn(),
]);
