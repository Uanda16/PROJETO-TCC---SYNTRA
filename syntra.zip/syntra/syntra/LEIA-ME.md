# SYNTRA — Conectando habilidades e conhecimentos

Plataforma para estudantes trocarem conhecimento: cada pessoa cadastra o que **pode ensinar** e o que **quer aprender**, encontra outras pessoas pela busca e envia **solicitações de conexão**. Quando a solicitação é aceita, as duas pessoas passam a ver o e-mail uma da outra para combinar a troca.

## O que funciona

| Recurso | Onde |
|---|---|
| Cadastro, entrar e sair (sessão de 7 dias) | Botões **Entrar / Cadastrar** no topo |
| Esqueci minha senha (link por e-mail, válido por 1 h e de uso único) | Janela **Entrar** |
| Meu perfil: dados, habilidades (ensinar / aprender), troca de senha, excluir conta | Menu do usuário → **Meu perfil** |
| Busca por habilidade ou nome, sem diferenciar acentos ("matematica" acha "Matemática") | Barra de busca da página inicial e página **Explorar** |
| Solicitações de conexão: enviar, aceitar, recusar, cancelar, desfazer | Botão **Conectar** e página **Conexões** |
| Aviso por e-mail de nova solicitação e de solicitação aceita (se o SMTP estiver configurado) | Automático |
| Formulário de contato | Página **Contato** |
| Números da plataforma | Página **Sobre** |

## Como rodar no XAMPP (Windows)

1. Copie a pasta `syntra` para `C:\xampp\htdocs\syntra`.
2. Abra o **XAMPP Control Panel** e inicie o **Apache** (o MySQL só é necessário se for usar MySQL).
3. Acesse **http://localhost/syntra/**

Pronto: por padrão o site usa **SQLite**, e o banco é criado sozinho em `data/syntra.sqlite`.

### Usar MySQL em vez de SQLite (opcional)

1. Inicie o **MySQL** no XAMPP e abra **http://localhost/phpmyadmin**.
2. Crie um banco vazio chamado `syntra` (agrupamento `utf8mb4_unicode_ci`).
3. Em `config/config.php`, troque `'driver' => 'sqlite'` por `'driver' => 'mysql'` e confira usuário e senha (no XAMPP o padrão é `root` sem senha).
4. As tabelas são criadas no primeiro acesso. Se preferir, importe `database/schema-mysql.sql` no phpMyAdmin.

### Usuários de demonstração (opcional)

Para testar a busca com pessoas fictícias, rode no terminal, dentro da pasta do projeto:

```
C:\xampp\php\php.exe database\seed.php
```

São criados 10 usuários (`demo1@exemplo.com` até `demo10@exemplo.com`, senha `demo1234`). Para removê-los:

```
C:\xampp\php\php.exe database\seed.php --remover
```

### Sem XAMPP (só PHP instalado)

```
php -S localhost:8000 router.php
```

e acesse http://localhost:8000. O `router.php` bloqueia as pastas internas, já que esse servidor ignora os arquivos `.htaccess`.

## Algo deu errado? Verifique a instalação

Abra **http://localhost/syntra/verificar.php**. A página confere a versão do PHP, as extensões, as permissões das pastas, a conexão com o banco e o e-mail, e mostra como corrigir cada item em vermelho. Por segurança, ela só abre no próprio computador.

Problemas mais comuns no XAMPP:

| Mensagem | Solução |
|---|---|
| "O PHP está sem o driver do banco (pdo_sqlite)" | XAMPP → botão **Config** do Apache → **PHP (php.ini)** → tire o `;` de `;extension=pdo_sqlite` → salve → **Stop/Start** no Apache. Ou use MySQL. |
| "O PHP está sem a extensão mbstring" | Mesmo caminho, linha `extension=mbstring`. |
| "Não tem permissão para gravar o banco" | Dê permissão de escrita à pasta `data` e evite deixar o site em "Arquivos de Programas". |
| "Não foi possível conectar ao MySQL" | Inicie o MySQL no XAMPP e confira `host` e `port` no `config/config.php`. |
| "O banco 'syntra' não existe" | Crie o banco no phpMyAdmin. |

Quando o site é acessado pelo próprio computador, os erros inesperados também mostram o detalhe técnico, o que ajuda a encontrar a causa.

## Configurar o envio de e-mails

Tudo fica em **`config/config.php`**:

- `email.destino_contato`: quem recebe o formulário de contato;
- `email.smtp.usuario` e `email.smtp.senha`: conta que envia os e-mails. Para Gmail, crie uma **Senha de app** (Conta Google → Segurança → Verificação em 2 etapas → Senhas de app);
- `site.url`: endereço do site, usado nos links dos e-mails (pode ficar vazio para detectar sozinho).

Para testar o "Esqueci minha senha" **no seu computador** sem configurar e-mail, coloque `'modo_desenvolvimento' => true`: o link aparece na tela. **Volte para `false` antes de publicar.**

## Publicar em uma hospedagem

1. Envie todos os arquivos. Nunca publique o `config/config.php` no GitHub: ele já está no `.gitignore`. Use o `config/config.example.php` como modelo.
2. Em hospedagem compartilhada, prefira **MySQL**.
3. As pastas `config/`, `includes/`, `data/` e `database/` são bloqueadas pelos arquivos `.htaccess` (Apache). Em servidor **Nginx**, bloqueie essas pastas na configuração do servidor ou aponte `db.sqlite_path` para fora da pasta pública.
4. Use **HTTPS**: o cookie de sessão passa a ser enviado só por conexão segura.

## Estrutura

```
index.html            Página única (todas as telas)
site.html             Redireciona para index.html (endereço antigo)
css/style.css         Layout da página inicial
css/app.css           Telas da aplicação (modais, perfil, busca, conexões)
js/main.js            Inicialização
js/api.js             Comunicação com o PHP (com proteção CSRF)
js/session.js         Usuário logado e cabeçalho
js/router.js          Navegação pelo # da URL (#explorar, #perfil, #usuario/12…)
js/auth.js            Entrar, cadastrar, esqueci a senha, sair
js/components.js      Cartão de usuário, botão Conectar, sugestões de habilidades
js/pages/*.js         Explorar, Meu perfil, Conexões, Perfil público, Redefinir senha
js/slider.js          Carrossel das fotos do topo
api/auth.php          Cadastro, login, logout, sessão, recuperação de senha
api/profile.php       Perfil, habilidades, senha, exclusão de conta
api/search.php        Busca de pessoas
api/users.php         Perfil público
api/connections.php   Solicitações de conexão
api/skills.php        Sugestões e habilidades populares
api/stats.php         Números da página Sobre
forms/contact.php     Formulário de contato
includes/             Banco, sessão, segurança, e-mail e diagnóstico de erros (não acessível pelo navegador)
verificar.php         Verificação da instalação (só abre em localhost)
config/               Configurações (não acessível pelo navegador)
data/                 Banco SQLite e sessões (não acessível pelo navegador)
database/             Esquema MySQL e dados de demonstração
vendor/php-email-form Biblioteca de e-mail (BootstrapMade + PHPMailer)
```

## Segurança

- Senhas guardadas com `password_hash` (bcrypt), nunca em texto.
- Consultas ao banco feitas com *prepared statements*, que protegem contra SQL injection.
- Token CSRF em todas as ações que alteram dados.
- Cookie de sessão `HttpOnly` e `SameSite=Lax`, com nova sessão gerada a cada login.
- Bloqueio de 15 minutos após 5 senhas erradas para o mesmo e-mail e IP.
- O "esqueci a senha" não revela se um e-mail está cadastrado.
- O e-mail de cada pessoa só aparece para conexões aceitas.
- Tudo o que os usuários digitam é escapado antes de aparecer na tela.
