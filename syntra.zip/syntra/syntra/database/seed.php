<?php
/**
 * SYNTRA - Dados de demonstração (opcional)
 *
 * Cria usuários FICTÍCIOS com habilidades, para testar a busca e as conexões.
 * Todos usam o domínio @exemplo.com e a senha: demo1234
 *
 * Como rodar (no terminal, dentro da pasta do projeto):
 *     php database/seed.php
 *
 * No XAMPP (Windows):
 *     C:\xampp\php\php.exe database\seed.php
 *
 * Para remover os usuários de demonstração depois:
 *     php database/seed.php --remover
 */

if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    exit('Execute este arquivo pelo terminal: php database/seed.php');
}

require __DIR__ . '/../includes/config.php';
require __DIR__ . '/../includes/db.php';
require __DIR__ . '/../includes/helpers.php';

$pdo = db();

if (in_array('--remover', $argv, true)) {
    $count = $pdo->exec("DELETE FROM users WHERE email LIKE '%@exemplo.com'");
    echo "Removidos $count usuários de demonstração.\n";
    exit;
}

$users = [
    ['Mariana Costa',     'Engenharia de Software', 'São Paulo - SP',      'Adoro programar e explicar com exemplos práticos. Prefiro encontros online à noite.',
        ['Python', 'JavaScript', 'Lógica de programação'], ['Inglês', 'Violão']],
    ['Lucas Andrade',     'Licenciatura em Letras', 'Campinas - SP',       'Professor de inglês em formação. Troco aulas de conversação por ajuda com Excel.',
        ['Inglês', 'Redação', 'Português'], ['Excel', 'Python']],
    ['Beatriz Nogueira',  'Design Gráfico',         'Belo Horizonte - MG', 'Designer apaixonada por tipografia e interfaces.',
        ['Figma', 'Design', 'Ilustração'], ['JavaScript', 'Fotografia']],
    ['Rafael Lima',       'Administração',          'Curitiba - PR',       'Planilhas são minha praia. Posso ajudar com finanças pessoais também.',
        ['Excel', 'Finanças pessoais', 'Power BI'], ['Espanhol', 'Oratória']],
    ['Camila Ferreira',   'Música - Bacharelado',   'Rio de Janeiro - RJ', 'Toco violão há 10 anos e dou aulas para iniciantes.',
        ['Violão', 'Teoria musical', 'Canto'], ['Inglês', 'Edição de vídeo']],
    ['João Pedro Alves',  'Ciência da Computação',  'Recife - PE',         'Monitor de cálculo na faculdade. Gosto de resolver exercícios junto.',
        ['Cálculo', 'Matemática', 'Física'], ['Design', 'Figma']],
    ['Ana Clara Souza',   'Jornalismo',             'Salvador - BA',       'Falo bem em público e posso ajudar com apresentações e TCC.',
        ['Oratória', 'Redação', 'Fotografia'], ['Power BI', 'Excel']],
    ['Diego Martins',     'Audiovisual',            'Porto Alegre - RS',   'Editor de vídeo freelancer. Premiere e DaVinci.',
        ['Edição de vídeo', 'Fotografia'], ['Python', 'Matemática']],
    ['Sofia Ribeiro',     'Relações Internacionais','Brasília - DF',       'Morei no Chile e falo espanhol fluente.',
        ['Espanhol', 'Inglês'], ['Violão', 'Ilustração']],
    ['Gabriel Rocha',     'Ensino Médio',           'Fortaleza - CE',      'Estudando para o vestibular, quero trocar conhecimento com quem já passou por isso.',
        ['Xadrez', 'Lógica de programação'], ['Cálculo', 'Física', 'Redação']],
];

$hash = password_hash('demo1234', PASSWORD_DEFAULT);
$created = 0;

foreach ($users as $i => [$name, $course, $city, $bio, $teach, $learn]) {
    $email = 'demo' . ($i + 1) . '@exemplo.com';

    $stmt = $pdo->prepare('SELECT id FROM users WHERE email = ?');
    $stmt->execute([$email]);
    if ($stmt->fetchColumn()) {
        continue;
    }

    $date = date('Y-m-d H:i:s', time() - ($i + 1) * 86400 * 3);
    $pdo->prepare(
        'INSERT INTO users (name, name_search, email, password_hash, course, city, bio, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
    )->execute([$name, normalize_text($name), $email, $hash, $course, $city, $bio, $date, $date]);
    $userId = (int) $pdo->lastInsertId();

    foreach (['teach' => $teach, 'learn' => $learn] as $kind => $skills) {
        foreach ($skills as $skill) {
            $slug = normalize_text($skill);
            $stmt = $pdo->prepare('SELECT id FROM skills WHERE slug = ?');
            $stmt->execute([$slug]);
            $skillId = $stmt->fetchColumn();
            if (!$skillId) {
                $pdo->prepare('INSERT INTO skills (name, slug, created_at) VALUES (?, ?, ?)')->execute([$skill, $slug, now()]);
                $skillId = $pdo->lastInsertId();
            }
            $pdo->prepare('INSERT INTO user_skills (user_id, skill_id, kind) VALUES (?, ?, ?)')->execute([$userId, $skillId, $kind]);
        }
    }
    $created++;
}

echo "Pronto! $created usuários de demonstração criados.\n";
echo "Entre com demo1@exemplo.com até demo10@exemplo.com e a senha demo1234\n";
