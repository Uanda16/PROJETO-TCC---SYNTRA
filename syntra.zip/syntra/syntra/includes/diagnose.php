<?php
/**
 * Traduz erros técnicos comuns de instalação (PHP / banco de dados)
 * em mensagens com a solução, em português.
 */

/** O acesso vem do próprio computador (ex.: XAMPP em localhost)? */
function is_local_request(): bool
{
    $ip = $_SERVER['REMOTE_ADDR'] ?? '';
    return in_array($ip, ['127.0.0.1', '::1'], true) || PHP_SAPI === 'cli';
}

/** Mostrar detalhes técnicos dos erros? Só no próprio computador ou em modo de desenvolvimento. */
function show_error_details(): bool
{
    return is_local_request() || (bool) config('site.modo_desenvolvimento', false);
}

/**
 * Retorna uma explicação com a solução, ou null se o erro não for conhecido.
 */
function diagnose_error(Throwable $e): ?string
{
    $msg = $e->getMessage();
    $driver = function_exists('config') ? config('db.driver', 'sqlite') : 'sqlite';
    $ext = $driver === 'mysql' ? 'pdo_mysql' : 'pdo_sqlite';

    if (stripos($msg, 'Class "PDO" not found') !== false || stripos($msg, "Class 'PDO' not found") !== false) {
        return 'O PHP está sem a extensão PDO. Abra o php.ini (no XAMPP: botão "Config" do Apache > PHP (php.ini)), '
            . 'remova o ";" do início da linha "extension=pdo_' . ($driver === 'mysql' ? 'mysql' : 'sqlite') . '", salve e reinicie o Apache.';
    }
    if (stripos($msg, 'could not find driver') !== false) {
        return "O PHP está sem o driver do banco ($ext). Abra o php.ini (no XAMPP: botão \"Config\" do Apache > PHP (php.ini)), "
            . "procure a linha \";extension=$ext\", remova o \";\" do início, salve e reinicie o Apache."
            . ($driver === 'sqlite' ? ' Outra opção é usar MySQL (veja o LEIA-ME.md).' : '');
    }
    if (preg_match('/unable to open database file|readonly database|attempt to write a readonly|disk I\/O error|Permission denied/i', $msg)) {
        return 'O PHP não tem permissão para gravar o banco de dados na pasta "data" do site. '
            . 'Dê permissão de escrita a essa pasta (em hospedagem Linux: permissão 775 ou 777 na pasta "data"). '
            . 'No Windows, verifique se a pasta não está como "somente leitura" e se o site não está dentro de uma pasta protegida, como "Arquivos de Programas".';
    }
    if (strpos($msg, '[1049]') !== false) {
        return 'O banco "' . config('db.database') . '" não existe no MySQL. Crie-o no phpMyAdmin (Novo > nome "'
            . config('db.database') . '" > agrupamento utf8mb4_unicode_ci) ou ajuste o nome em config/config.php.';
    }
    if (strpos($msg, '[1045]') !== false) {
        return 'O MySQL recusou o usuário ou a senha. Confira "username" e "password" em config/config.php '
            . '(no XAMPP o padrão é usuário "root" e senha vazia).';
    }
    if (strpos($msg, '[2002]') !== false || stripos($msg, 'Connection refused') !== false || stripos($msg, 'No such file or directory') !== false) {
        return 'Não foi possível conectar ao MySQL. Verifique se o MySQL está iniciado no XAMPP '
            . 'e se "host" e "port" em config/config.php estão corretos.';
    }
    if (stripos($msg, 'mb_') !== false && stripos($msg, 'undefined function') !== false) {
        return 'O PHP está sem a extensão mbstring. No php.ini, remova o ";" da linha "extension=mbstring" e reinicie o Apache.';
    }
    return null;
}
