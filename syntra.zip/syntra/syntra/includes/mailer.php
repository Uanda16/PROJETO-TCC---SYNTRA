<?php
/**
 * Envio de e-mails do sistema usando a mesma biblioteca do formulário
 * de contato (vendor/php-email-form, com PHPMailer embutido).
 */

require_once __DIR__ . '/../vendor/php-email-form/php-email-form.php';

/** O SMTP está configurado em config/config.php? */
function mail_configured(): bool
{
    return trim((string) config('email.smtp.senha', '')) !== '';
}

/**
 * Envia um e-mail em HTML.
 * Retorna true se enviou, ou o texto do erro.
 *
 * @param string $html Corpo já em HTML (escape os dados do usuário antes!)
 */
function send_mail(string $to, string $subject, string $html)
{
    $mail = new PHP_Email_Form;
    $mail->ajax = false;
    $mail->to = $to;
    $mail->from_name = config('site.nome', 'SYNTRA');
    $mail->from_email = config('email.smtp.usuario') ?: config('email.destino_contato');
    $mail->subject = $subject;
    $mail->message = $html;

    if (mail_configured()) {
        $mail->smtp = [
            'host'       => config('email.smtp.host'),
            'username'   => config('email.smtp.usuario'),
            'password'   => config('email.smtp.senha'),
            'port'       => config('email.smtp.porta', 587),
            'encryption' => config('email.smtp.encryption', 'tls'),
        ];
    }

    $result = $mail->send();
    if ($result === 'OK') {
        return true;
    }
    error_log('[SYNTRA] Falha ao enviar e-mail: ' . strip_tags((string) $result));
    return (string) $result;
}

/** Monta o HTML padrão dos e-mails do SYNTRA. */
function mail_template(string $title, string $bodyHtml, ?string $buttonText = null, ?string $buttonUrl = null): string
{
    $button = '';
    if ($buttonText && $buttonUrl) {
        $button = '<p style="margin:28px 0"><a href="' . htmlspecialchars($buttonUrl) . '" '
            . 'style="background:#6d4bf0;color:#fff;padding:12px 28px;border-radius:999px;'
            . 'text-decoration:none;font-weight:bold;display:inline-block">'
            . htmlspecialchars($buttonText) . '</a></p>';
    }
    return '<div style="font-family:Arial,sans-serif;max-width:560px;margin:0 auto;color:#12163f">'
        . '<h2 style="color:#6d4bf0;margin-bottom:8px">SYNTRA</h2>'
        . '<h3 style="margin-top:0">' . htmlspecialchars($title) . '</h3>'
        . $bodyHtml . $button
        . '<p style="color:#6b7190;font-size:12px;margin-top:32px">'
        . 'Você recebeu este e-mail porque tem uma conta na plataforma SYNTRA.</p></div>';
}
