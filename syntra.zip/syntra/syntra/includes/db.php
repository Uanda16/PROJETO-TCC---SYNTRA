<?php
/**
 * Conexão com o banco (SQLite ou MySQL) e criação automática das tabelas.
 */

const SCHEMA_VERSION = 1;

function db(): PDO
{
    static $pdo = null;
    if ($pdo !== null) {
        return $pdo;
    }

    $driver = config('db.driver', 'sqlite');
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];

    if ($driver === 'mysql') {
        $dsn = sprintf(
            'mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4',
            config('db.host', '127.0.0.1'),
            (int) config('db.port', 3306),
            config('db.database', 'syntra')
        );
        $pdo = new PDO($dsn, config('db.username', 'root'), config('db.password', ''), $options);
        $pdo->exec("SET time_zone = '" . date('P') . "'");
    } else {
        $path = config('db.sqlite_path', __DIR__ . '/../data/syntra.sqlite');
        $dir = dirname($path);
        if (!is_dir($dir)) {
            mkdir($dir, 0775, true);
        }
        $pdo = new PDO('sqlite:' . $path, null, null, $options);
        $pdo->exec('PRAGMA foreign_keys = ON');
        $pdo->exec('PRAGMA journal_mode = WAL');
        $pdo->exec('PRAGMA busy_timeout = 5000');
    }

    db_install($pdo, $driver);
    return $pdo;
}

function db_driver(): string
{
    return config('db.driver', 'sqlite') === 'mysql' ? 'mysql' : 'sqlite';
}

/**
 * Cria as tabelas se ainda não existirem.
 */
function db_install(PDO $pdo, string $driver): void
{
    try {
        $version = (int) $pdo->query("SELECT meta_value FROM app_meta WHERE meta_key = 'schema_version'")->fetchColumn();
        if ($version >= SCHEMA_VERSION) {
            return;
        }
    } catch (PDOException $e) {
        // Tabela ainda não existe: segue para a instalação
    }

    foreach (db_schema($driver) as $sql) {
        try {
            $pdo->exec($sql);
        } catch (PDOException $e) {
            // MySQL não tem "CREATE INDEX IF NOT EXISTS": ignora índice já existente
            if (stripos($sql, 'CREATE INDEX') !== 0) {
                throw $e;
            }
        }
    }

    $pdo->prepare('DELETE FROM app_meta WHERE meta_key = ?')->execute(['schema_version']);
    $pdo->prepare('INSERT INTO app_meta (meta_key, meta_value) VALUES (?, ?)')
        ->execute(['schema_version', (string) SCHEMA_VERSION]);
}

function db_schema(string $driver): array
{
    if ($driver === 'mysql') {
        $id = 'INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY';
        $fk = 'INT UNSIGNED';
        $tail = ' ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci';
    } else {
        $id = 'INTEGER PRIMARY KEY AUTOINCREMENT';
        $fk = 'INTEGER';
        $tail = '';
    }

    return [
        "CREATE TABLE IF NOT EXISTS app_meta (
            meta_key   VARCHAR(50) NOT NULL PRIMARY KEY,
            meta_value VARCHAR(255) NOT NULL
        )$tail",

        "CREATE TABLE IF NOT EXISTS users (
            id            $id,
            name          VARCHAR(80)  NOT NULL,
            name_search   VARCHAR(80)  NOT NULL,
            email         VARCHAR(190) NOT NULL UNIQUE,
            password_hash VARCHAR(255) NOT NULL,
            course        VARCHAR(100) NULL,
            city          VARCHAR(80)  NULL,
            bio           TEXT NULL,
            created_at    DATETIME NOT NULL,
            updated_at    DATETIME NOT NULL
        )$tail",

        "CREATE TABLE IF NOT EXISTS skills (
            id         $id,
            name       VARCHAR(40) NOT NULL,
            slug       VARCHAR(40) NOT NULL UNIQUE,
            created_at DATETIME NOT NULL
        )$tail",

        "CREATE TABLE IF NOT EXISTS user_skills (
            user_id  $fk NOT NULL,
            skill_id $fk NOT NULL,
            kind     VARCHAR(5) NOT NULL,
            PRIMARY KEY (user_id, skill_id, kind),
            FOREIGN KEY (user_id)  REFERENCES users(id)  ON DELETE CASCADE,
            FOREIGN KEY (skill_id) REFERENCES skills(id) ON DELETE CASCADE
        )$tail",

        "CREATE TABLE IF NOT EXISTS connections (
            id           $id,
            requester_id $fk NOT NULL,
            addressee_id $fk NOT NULL,
            skill_id     $fk NULL,
            message      TEXT NULL,
            status       VARCHAR(10) NOT NULL,
            created_at   DATETIME NOT NULL,
            updated_at   DATETIME NOT NULL,
            UNIQUE (requester_id, addressee_id),
            FOREIGN KEY (requester_id) REFERENCES users(id)  ON DELETE CASCADE,
            FOREIGN KEY (addressee_id) REFERENCES users(id)  ON DELETE CASCADE,
            FOREIGN KEY (skill_id)     REFERENCES skills(id) ON DELETE SET NULL
        )$tail",

        "CREATE TABLE IF NOT EXISTS password_resets (
            id         $id,
            user_id    $fk NOT NULL,
            token_hash CHAR(64) NOT NULL UNIQUE,
            expires_at DATETIME NOT NULL,
            used_at    DATETIME NULL,
            created_at DATETIME NOT NULL,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        )$tail",

        "CREATE TABLE IF NOT EXISTS login_attempts (
            id         $id,
            email      VARCHAR(190) NOT NULL,
            ip         VARCHAR(45)  NOT NULL,
            created_at DATETIME NOT NULL
        )$tail",

        "CREATE INDEX " . ($driver === 'sqlite' ? 'IF NOT EXISTS ' : '') . "idx_login_attempts ON login_attempts (email, ip, created_at)",
        "CREATE INDEX " . ($driver === 'sqlite' ? 'IF NOT EXISTS ' : '') . "idx_user_skills_skill ON user_skills (skill_id, kind)",
        "CREATE INDEX " . ($driver === 'sqlite' ? 'IF NOT EXISTS ' : '') . "idx_connections_addressee ON connections (addressee_id, status)",
    ];
}

function now(): string
{
    return date('Y-m-d H:i:s');
}
