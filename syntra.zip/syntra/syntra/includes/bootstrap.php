<?php
/**
 * Carregado no início de todos os arquivos da pasta api/.
 * - Respostas em JSON
 * - Sessão segura
 * - Proteção CSRF em requisições que alteram dados
 */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/diagnose.php';
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/auth.php';

header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-store');

// Nunca mostrar erros do PHP para o visitante: eles vão para o log
ini_set('display_errors', '0');
error_reporting(E_ALL);

set_exception_handler(function (Throwable $e) {
    error_log('[SYNTRA] ' . get_class($e) . ': ' . $e->getMessage() . ' em ' . $e->getFile() . ':' . $e->getLine());

    // Erros de instalação conhecidos: mostra a causa e como resolver
    if ($help = diagnose_error($e)) {
        json_error('Problema na configuração do servidor: ' . $help, 500);
    }

    $message = 'Ocorreu um erro inesperado. Tente novamente em instantes.';
    if (show_error_details()) {
        // No seu computador (localhost) mostra o detalhe técnico para facilitar a correção
        $message .= ' Detalhe técnico: ' . $e->getMessage()
            . ' (' . basename($e->getFile()) . ', linha ' . $e->getLine() . ')';
    }
    json_error($message, 500);
});

start_secure_session();

// Requisições que alteram dados precisam do token CSRF
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    verify_csrf();
}
