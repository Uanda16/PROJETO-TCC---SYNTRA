<?php
/**
 * Sessão, login e proteção CSRF.
 */

const SESSION_LIFETIME   = 60 * 60 * 24 * 7;  // 7 dias conectado
const LOGIN_MAX_ATTEMPTS = 5;                 // tentativas erradas...
const LOGIN_LOCK_MINUTES = 15;                // ...dentro deste intervalo

function start_secure_session(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        return;
    }

    // Sessões salvas na pasta do projeto (protegida), com validade de 7 dias
    $path = __DIR__ . '/../data/sessions';
    if (!is_dir($path)) {
        @mkdir($path, 0770, true);
    }
    if (is_dir($path) && is_writable($path)) {
        session_save_path($path);
    }
    ini_set('session.gc_maxlifetime', (string) SESSION_LIFETIME);
    ini_set('session.use_strict_mode', '1');

    $https = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
    session_name('SYNTRASESSID');
    session_set_cookie_params([
        'lifetime' => SESSION_LIFETIME,
        'path'     => '/',
        'secure'   => $https,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();

    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
}

function csrf_token(): string
{
    return $_SESSION['csrf'];
}

function verify_csrf(): void
{
    $sent = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    if (!is_string($sent) || !hash_equals($_SESSION['csrf'] ?? '', $sent)) {
        json_error('Sua sessão expirou. Recarregue a página e tente novamente.', 419);
    }
}

function current_user_id(): ?int
{
    return isset($_SESSION['user_id']) ? (int) $_SESSION['user_id'] : null;
}

function current_user(): ?array
{
    static $user = false;
    if ($user === false) {
        $user = null;
        if ($id = current_user_id()) {
            $stmt = db()->prepare('SELECT * FROM users WHERE id = ?');
            $stmt->execute([$id]);
            $user = $stmt->fetch() ?: null;
            if (!$user) {
                // Conta excluída: limpa a sessão
                unset($_SESSION['user_id']);
            }
        }
    }
    return $user;
}

function require_login(): array
{
    $user = current_user();
    if (!$user) {
        json_error('Você precisa entrar na sua conta para continuar.', 401);
    }
    return $user;
}

function login_user(int $userId): void
{
    session_regenerate_id(true);
    $_SESSION['user_id'] = $userId;
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
}

function logout_user(): void
{
    $_SESSION = [];
    session_regenerate_id(true);
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
}

/* ---------- Limite de tentativas de login ---------- */

function login_is_locked(string $email): bool
{
    $since = date('Y-m-d H:i:s', time() - LOGIN_LOCK_MINUTES * 60);
    $stmt = db()->prepare('SELECT COUNT(*) FROM login_attempts WHERE email = ? AND ip = ? AND created_at > ?');
    $stmt->execute([$email, client_ip(), $since]);
    return (int) $stmt->fetchColumn() >= LOGIN_MAX_ATTEMPTS;
}

function login_register_failure(string $email): void
{
    db()->prepare('INSERT INTO login_attempts (email, ip, created_at) VALUES (?, ?, ?)')
        ->execute([$email, client_ip(), now()]);
    // Limpeza de registros antigos
    db()->prepare('DELETE FROM login_attempts WHERE created_at < ?')
        ->execute([date('Y-m-d H:i:s', time() - 86400)]);
}

function login_clear_failures(string $email): void
{
    db()->prepare('DELETE FROM login_attempts WHERE email = ? AND ip = ?')->execute([$email, client_ip()]);
}

/* ---------- Validação de senha ---------- */

function password_problem(string $password): ?string
{
    if (mb_strlen($password) < 8) {
        return 'A senha precisa ter pelo menos 8 caracteres.';
    }
    if (strlen($password) > 72) {
        return 'A senha pode ter no máximo 72 caracteres.';
    }
    if (!preg_match('/[A-Za-z]/', $password) || !preg_match('/\d/', $password)) {
        return 'Use letras e números na senha.';
    }
    return null;
}
