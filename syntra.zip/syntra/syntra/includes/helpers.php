<?php
/**
 * Funções utilitárias da API.
 */

/** Envia uma resposta JSON e encerra. */
function json_response(array $data = [], int $status = 200): void
{
    http_response_code($status);
    echo json_encode(['ok' => true] + $data, JSON_UNESCAPED_UNICODE);
    exit;
}

/** Envia um erro JSON e encerra. $fields = erros por campo do formulário. */
function json_error(string $message, int $status = 400, array $fields = []): void
{
    http_response_code($status);
    $body = ['ok' => false, 'error' => $message];
    if ($fields) {
        $body['fields'] = $fields;
    }
    echo json_encode($body, JSON_UNESCAPED_UNICODE);
    exit;
}

/** Lê o corpo JSON da requisição. */
function input(): array
{
    static $data = null;
    if ($data === null) {
        $raw = file_get_contents('php://input');
        $data = json_decode($raw ?: '[]', true);
        if (!is_array($data)) {
            $data = [];
        }
    }
    return $data;
}

/** Texto de um campo, sem espaços extras. */
function input_str(string $key, int $maxLength = 255): string
{
    $value = input()[$key] ?? '';
    if (!is_string($value) && !is_numeric($value)) {
        return '';
    }
    $value = trim(preg_replace('/[ \t]+/u', ' ', (string) $value));
    return mb_substr($value, 0, $maxLength);
}

function require_method(string $method): void
{
    if ($_SERVER['REQUEST_METHOD'] !== $method) {
        json_error('Método não permitido.', 405);
    }
}

/** Ação pedida na URL (?action=...). */
function action(): string
{
    return (string) ($_GET['action'] ?? '');
}

/**
 * Versão "normalizada" de um texto para busca:
 * minúsculas e sem acentos ("Matemática" -> "matematica").
 */
function normalize_text(string $text): string
{
    $text = mb_strtolower(trim($text), 'UTF-8');
    $map = [
        'á'=>'a','à'=>'a','â'=>'a','ã'=>'a','ä'=>'a',
        'é'=>'e','è'=>'e','ê'=>'e','ë'=>'e',
        'í'=>'i','ì'=>'i','î'=>'i','ï'=>'i',
        'ó'=>'o','ò'=>'o','ô'=>'o','õ'=>'o','ö'=>'o',
        'ú'=>'u','ù'=>'u','û'=>'u','ü'=>'u',
        'ç'=>'c','ñ'=>'n',
    ];
    $text = strtr($text, $map);
    return preg_replace('/\s+/u', ' ', $text);
}

/**
 * Escapa % e _ para uso seguro dentro de LIKE.
 * Use sempre com: LIKE ? ESCAPE '!'  (funciona igual no SQLite e no MySQL)
 */
function like_escape(string $text): string
{
    return str_replace(['!', '%', '_'], ['!!', '!%', '!_'], $text);
}

function client_ip(): string
{
    return substr($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0', 0, 45);
}

/** Endereço base do site (para links enviados por e-mail). */
function site_url(): string
{
    $configured = rtrim((string) config('site.url', ''), '/');
    if ($configured !== '') {
        return $configured;
    }
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    // Script fica em /api/arquivo.php -> sobe um nível
    $path = rtrim(str_replace('\\', '/', dirname(dirname($_SERVER['SCRIPT_NAME'] ?? '/'))), '/');
    return ($https ? 'https' : 'http') . '://' . $host . $path;
}

/** Dados públicos de um usuário (nunca inclui senha; e-mail só quando permitido). */
function public_user(array $user, bool $includeEmail = false): array
{
    $data = [
        'id'         => (int) $user['id'],
        'name'       => $user['name'],
        'course'     => $user['course'] ?? '',
        'city'       => $user['city'] ?? '',
        'bio'        => $user['bio'] ?? '',
        'created_at' => $user['created_at'] ?? null,
    ];
    if ($includeEmail) {
        $data['email'] = $user['email'];
    }
    return $data;
}

/** Habilidades de vários usuários de uma vez: [user_id => ['teach'=>[], 'learn'=>[]]] */
function skills_for_users(array $userIds): array
{
    $result = [];
    foreach ($userIds as $id) {
        $result[(int) $id] = ['teach' => [], 'learn' => []];
    }
    if (!$userIds) {
        return $result;
    }
    $placeholders = implode(',', array_fill(0, count($userIds), '?'));
    $stmt = db()->prepare(
        "SELECT us.user_id, us.kind, s.name
           FROM user_skills us
           JOIN skills s ON s.id = us.skill_id
          WHERE us.user_id IN ($placeholders)
          ORDER BY s.name"
    );
    $stmt->execute(array_values($userIds));
    foreach ($stmt as $row) {
        $result[(int) $row['user_id']][$row['kind']][] = $row['name'];
    }
    return $result;
}

/** Status da conexão entre o usuário logado e outro usuário. */
function connection_between(int $me, int $other): ?array
{
    $stmt = db()->prepare(
        'SELECT * FROM connections
          WHERE (requester_id = ? AND addressee_id = ?)
             OR (requester_id = ? AND addressee_id = ?)'
    );
    $stmt->execute([$me, $other, $other, $me]);
    $row = $stmt->fetch();
    return $row ?: null;
}

/** Converte a linha de conexão no ponto de vista do usuário logado. */
function connection_state(?array $conn, int $me): ?array
{
    if (!$conn) {
        return null;
    }
    $sent = (int) $conn['requester_id'] === $me;
    return [
        'id'        => (int) $conn['id'],
        'status'    => $conn['status'],          // pending | accepted | declined
        'direction' => $sent ? 'sent' : 'received',
    ];
}

/** Dados do usuário logado enviados ao navegador. */
function me_payload(array $user): array
{
    $skills = skills_for_users([(int) $user['id']])[(int) $user['id']];

    $stmt = db()->prepare("SELECT COUNT(*) FROM connections WHERE addressee_id = ? AND status = 'pending'");
    $stmt->execute([$user['id']]);

    return public_user($user, true) + [
        'teach'   => $skills['teach'],
        'learn'   => $skills['learn'],
        'pending' => (int) $stmt->fetchColumn(),
    ];
}

/** Nome válido: letras (com acento), espaços, apóstrofo, hífen e ponto. */
function valid_name(string $name): bool
{
    return mb_strlen($name) >= 3 && (bool) preg_match("/^[\\p{L}\\p{M}][\\p{L}\\p{M}' .-]*$/u", $name);
}
