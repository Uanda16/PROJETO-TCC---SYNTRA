<?php
/**
 * Carrega config/config.php (uma única vez).
 */
function app_config(): array
{
    static $config = null;
    if ($config === null) {
        $file = __DIR__ . '/../config/config.php';
        if (!file_exists($file)) {
            $file = __DIR__ . '/../config/config.example.php';
        }
        $config = require $file;
    }
    return $config;
}

/**
 * Lê um valor com notação de ponto: config('db.driver')
 */
function config(string $key, $default = null)
{
    $value = app_config();
    foreach (explode('.', $key) as $part) {
        if (!is_array($value) || !array_key_exists($part, $value)) {
            return $default;
        }
        $value = $value[$part];
    }
    return $value;
}

date_default_timezone_set(config('site.timezone', 'America/Sao_Paulo'));
