<?php
/**
 * SYNTRA - Verificação da instalação
 *
 * Abra no navegador: http://localhost/syntra/verificar.php
 * Mostra se o PHP, o banco de dados e as pastas estão prontos.
 * Por segurança, só funciona no próprio computador (localhost)
 * ou com 'modo_desenvolvimento' => true no config.php.
 */

require __DIR__ . '/includes/config.php';
require __DIR__ . '/includes/diagnose.php';

header('Content-Type: text/html; charset=utf-8');
header('Cache-Control: no-store');
ini_set('display_errors', '0');

if (!show_error_details()) {
    http_response_code(403);
    exit('Esta página só pode ser aberta no próprio servidor (localhost).');
}

$driver = config('db.driver', 'sqlite') === 'mysql' ? 'mysql' : 'sqlite';
$checks = [];   // [status: ok|erro|aviso, título, detalhe]

function check(string $status, string $title, string $detail = ''): void
{
    global $checks;
    $checks[] = [$status, $title, $detail];
}

/* ---------- PHP ---------- */
check(
    version_compare(PHP_VERSION, '7.4.0', '>=') ? 'ok' : 'erro',
    'PHP ' . PHP_VERSION,
    version_compare(PHP_VERSION, '7.4.0', '>=') ? '' : 'É necessário PHP 7.4 ou mais novo. Atualize o XAMPP.'
);

$extensions = [
    'pdo'      => 'Acesso ao banco de dados',
    'pdo_' . $driver => $driver === 'mysql' ? 'Driver do MySQL' : 'Driver do SQLite',
    'mbstring' => 'Textos com acento',
    'openssl'  => 'Envio de e-mail seguro (SMTP) e senhas',
    'json'     => 'Comunicação com a página',
];
foreach ($extensions as $ext => $label) {
    $loaded = extension_loaded($ext);
    check(
        $loaded ? 'ok' : 'erro',
        "Extensão $ext — $label",
        $loaded ? '' : "Abra o php.ini (XAMPP: botão \"Config\" do Apache > PHP (php.ini)), remova o \";\" da linha \"extension=$ext\", salve e reinicie o Apache."
    );
}

/* ---------- Configuração ---------- */
$hasConfig = file_exists(__DIR__ . '/config/config.php');
check(
    $hasConfig ? 'ok' : 'aviso',
    'Arquivo config/config.php',
    $hasConfig ? '' : 'Não encontrado: usando config.example.php. Copie o exemplo para config.php e ajuste.'
);

/* ---------- Pastas ---------- */
$dataDir = __DIR__ . '/data';
if ($driver === 'sqlite') {
    $dbFile = config('db.sqlite_path');
    $dbDir = dirname($dbFile);
    $writable = is_dir($dbDir) ? is_writable($dbDir) : is_writable(dirname($dbDir));
    check(
        $writable ? 'ok' : 'erro',
        'Pasta do banco SQLite pode ser gravada',
        $writable ? realpath($dbDir) ?: $dbDir
            : 'Sem permissão de escrita em "' . $dbDir . '". Dê permissão de escrita a essa pasta (Linux: chmod 775 ou 777).'
    );
}
$sessions = $dataDir . '/sessions';
$sessOk = is_dir($sessions) ? is_writable($sessions) : is_writable($dataDir);
check(
    $sessOk ? 'ok' : 'aviso',
    'Pasta de sessões (data/sessions) pode ser gravada',
    $sessOk ? '' : 'Sem permissão: o login vai usar a pasta de sessões padrão do PHP (funciona, mas pode desconectar antes de 7 dias).'
);

/* ---------- Banco de dados ---------- */
$dbOk = false;
try {
    require __DIR__ . '/includes/db.php';
    $users = (int) db()->query('SELECT COUNT(*) FROM users')->fetchColumn();
    $dbOk = true;
    check('ok', 'Banco de dados (' . ($driver === 'mysql' ? 'MySQL' : 'SQLite') . ') conectado e tabelas criadas', "$users usuário(s) cadastrado(s).");
} catch (Throwable $e) {
    check('erro', 'Banco de dados (' . ($driver === 'mysql' ? 'MySQL' : 'SQLite') . ')',
        (diagnose_error($e) ?? 'Erro: ' . $e->getMessage()));
}

/* ---------- Teste de gravação ---------- */
if ($dbOk) {
    try {
        $pdo = db();
        $pdo->beginTransaction();
        $pdo->prepare('INSERT INTO login_attempts (email, ip, created_at) VALUES (?, ?, ?)')
            ->execute(['teste@verificacao', '0.0.0.0', now()]);
        $pdo->rollBack();
        check('ok', 'Gravação no banco de dados', 'Teste de gravação feito e desfeito com sucesso.');
    } catch (Throwable $e) {
        if (isset($pdo) && $pdo->inTransaction()) {
            $pdo->rollBack();
        }
        check('erro', 'Gravação no banco de dados', diagnose_error($e) ?? 'Erro: ' . $e->getMessage());
    }
}

/* ---------- E-mail ---------- */
$smtp = trim((string) config('email.smtp.senha', '')) !== '';
check(
    $smtp ? 'ok' : 'aviso',
    'E-mail (SMTP)',
    $smtp ? 'Configurado para ' . config('email.smtp.usuario')
          : 'Não configurado: "Esqueci minha senha", avisos de conexão e o formulário de contato não vão enviar e-mails. Preencha email.smtp no config.php.'
);

if (config('site.modo_desenvolvimento') && !is_local_request()) {
    check('aviso', 'Modo de desenvolvimento ligado', 'Desligue (false) no config.php antes de publicar o site.');
}

$errors = count(array_filter($checks, fn($c) => $c[0] === 'erro'));
$icons = ['ok' => '✓', 'erro' => '✕', 'aviso' => '!'];
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex">
    <title>Verificação da instalação - SYNTRA</title>
    <style>
        body { font-family: 'Segoe UI', Arial, sans-serif; background: #f6f4fd; color: #12163f; margin: 0; padding: 32px 16px; }
        main { max-width: 760px; margin: 0 auto; background: #fff; border-radius: 20px; padding: 28px; box-shadow: 0 10px 30px rgba(79,70,229,.08); }
        h1 { margin: 0 0 6px; font-size: 24px; }
        .summary { padding: 14px 16px; border-radius: 12px; margin: 16px 0 22px; font-weight: 600; }
        .summary.ok { background: #e8f8ee; color: #157a3c; }
        .summary.erro { background: #fdecec; color: #b42318; }
        ul { list-style: none; padding: 0; margin: 0; display: grid; gap: 10px; }
        li { display: grid; grid-template-columns: 30px 1fr; gap: 10px; padding: 12px 14px; border: 1px solid #e4e2f3; border-radius: 12px; }
        .icon { width: 26px; height: 26px; border-radius: 50%; display: grid; place-items: center; color: #fff; font-weight: 700; font-size: 14px; }
        .ok .icon { background: #16a34a; } .erro .icon { background: #dc2626; } .aviso .icon { background: #f59e0b; }
        li.erro { border-color: #fbd5d5; background: #fff8f8; }
        strong { display: block; }
        small { color: #3f4566; line-height: 1.5; display: block; margin-top: 2px; word-break: break-word; }
        a { color: #6d28d9; font-weight: 600; }
    </style>
</head>
<body>
<main>
    <h1>Verificação da instalação</h1>
    <p>Banco configurado: <strong style="display:inline"><?= $driver === 'mysql' ? 'MySQL' : 'SQLite' ?></strong></p>

    <div class="summary <?= $errors ? 'erro' : 'ok' ?>">
        <?= $errors
            ? "Encontramos $errors problema(s). Corrija os itens em vermelho e recarregue esta página."
            : 'Tudo pronto! O cadastro e o login devem funcionar.' ?>
    </div>

    <ul>
        <?php foreach ($checks as [$status, $title, $detail]): ?>
            <li class="<?= $status ?>">
                <span class="icon"><?= $icons[$status] ?></span>
                <span>
                    <strong><?= htmlspecialchars($title) ?></strong>
                    <?php if ($detail !== ''): ?><small><?= htmlspecialchars($detail) ?></small><?php endif; ?>
                </span>
            </li>
        <?php endforeach; ?>
    </ul>

    <p style="margin-top:22px"><a href="index.html">&larr; Voltar ao site</a></p>
</main>
</body>
</html>
